import React, { useState, useRef, useEffect } from 'react';
import { 
  Zap, 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  TrendingUp, 
  HelpCircle, 
  ShieldCheck, 
  Layers,
  RotateCcw,
  Clock,
  Globe,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Trash2
} from 'lucide-react';
import { useSimulator } from '../context/SimulatorContext';
import { Holding } from '../types';
import { formatINR } from '../utils/formatters';

interface Message {
  id: string;
  sender: 'user' | 'chanakya';
  text: string;
  timestamp: string;
  responseMode?: string;
  sources?: Array<{ title: string; url?: string }>;
  generatedAt?: string;
}

const QUICK_PROMPTS = [
  'Explain this company in simple terms',
  'What could affect this sector?',
  'Help me review my trade plan',
  'Explain why diversification matters here',
  'Challenge my thesis and show the downside risks',
  'Explain P/E ratio like I am 14 years old',
];

interface AIStatus {
  configured: boolean;
  searchGrounding: boolean;
  checked: boolean;
  checkedAt?: string;
}

const welcomeMessage = (status?: AIStatus) => {
  const capabilityNote = status?.checked
    ? status.configured
      ? 'Gemini is connected, with Google Search grounding enabled for current market questions.'
      : 'Gemini is not configured on this server, so I will provide clearly labeled offline educational guidance instead of live market claims.'
    : 'Checking whether the online AI service is available…';
  return `Namaste, Rookie Investor! 🙏 I am **Chanakya Jr.**, your Dalal Street learning coach.\n\nYou have **₹10,00,000** in virtual money to practise with. Ask about valuation, risk, portfolio construction, or market concepts.\n\n*${capabilityNote}*`;
};

export const ChanakyaMentor: React.FC = () => {
  const { portfolioValue, cashBalance, holdings, userLevel, userXP, unlockBadge } = useSimulator();
  const [aiStatus, setAiStatus] = useState<AIStatus>({ configured: false, searchGrounding: false, checked: false });

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'chanakya',
      text: welcomeMessage(),
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speechSynthesisActive, setSpeechSynthesisActive] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    fetch('/api/gemini/status')
      .then((response) => response.json())
      .then((data) => {
        const nextStatus = {
          configured: Boolean(data.configured),
          searchGrounding: Boolean(data.searchGrounding),
          checked: true,
          checkedAt: data.checkedAt,
        };
        setAiStatus(nextStatus);
        setMessages((previous) => previous.map((message) => message.id === 'welcome' ? { ...message, text: welcomeMessage(nextStatus) } : message));
      })
      .catch(() => {
        const nextStatus = { configured: false, searchGrounding: false, checked: true };
        setAiStatus(nextStatus);
        setMessages((previous) => previous.map((message) => message.id === 'welcome' ? { ...message, text: welcomeMessage(nextStatus) } : message));
      });
  }, []);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Text to Speech playback helper
  const speakText = (text: string, msgId: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown formatting for cleaner speech
    const cleanText = text.replace(/[*#_`]/g, '').replace(/\[(.*?)\]\(.*?\)/g, '$1');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    // Try to find an Indian English or natural voice if available
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.lang.includes('en-IN') || v.name.includes('India')) ||
      voices.find(v => v.lang.startsWith('en')) || null;
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Voice Input using Web Speech Recognition
  const toggleSpeechRecognition = () => {
    if (typeof window === 'undefined') return;
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported on this browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputText(prev => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleClearChat = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingMsgId(null);
    setMessages([
      {
        id: 'welcome',
        sender: 'chanakya',
        text: welcomeMessage(aiStatus),
        timestamp: 'Just now',
      },
    ]);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim() || isLoading) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      // Send to server-side Gemini API endpoint
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages,
          portfolioContext: {
            portfolioValue,
            cashBalance,
            holdingsCount: Object.keys(holdings).length,
            holdings: (Object.values(holdings) as Holding[]).map((h: Holding) => ({
              symbol: h.symbol,
              quantity: h.quantity,
              avgBuyPrice: h.avgBuyPrice,
            })),
            level: userLevel.level,
            xp: userXP,
          },
        }),
      });

      let botReply = 'Apologies rookie! The market floor was busy. Try asking me again!';
      let responseMeta: Pick<Message, 'responseMode' | 'sources' | 'generatedAt'> = {};
      if (response.ok) {
        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const data = await response.json();
          botReply = data.text || data.reply || data.message || botReply;
          responseMeta = { responseMode: data.mode, sources: Array.isArray(data.sources) ? data.sources : [], generatedAt: data.generatedAt };
          if (data.mode === 'offline-educational') {
            setAiStatus({ configured: false, searchGrounding: false, checked: true });
          }
        }
      }

      const botMsgId = (Date.now() + 1).toString();
      const botMsg: Message = {
        id: botMsgId,
        sender: 'chanakya',
        text: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        ...responseMeta,
      };

      setMessages((prev) => [...prev, botMsg]);
      unlockBadge('badge-mentor');

      // If auto audio is enabled, read aloud
      if (speechSynthesisActive) {
        speakText(botReply, botMsgId);
      }
    } catch {
      const errMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'chanakya',
        text: 'Chanakya is currently reviewing Dalal Street charts. Please ask your question again in a moment!',
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl shadow-sm flex flex-col h-[78vh] overflow-hidden text-slate-900">
      
      {/* Header */}
      <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-slate-900 p-0.5 shadow-md flex items-center justify-center text-white">
            <Zap className="w-5 h-5 fill-[#4F46E5] text-indigo-600" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-extrabold text-slate-900 text-base">Chanakya Jr. AI Mentor</h3>
               <span className={`${aiStatus.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'} text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1`}>
                 <span className={`w-1.5 h-1.5 rounded-full ${aiStatus.configured ? 'bg-emerald-600 animate-pulse' : 'bg-amber-600'}`}></span>
                 {aiStatus.checked ? (aiStatus.configured ? 'ONLINE AI' : 'OFFLINE GUIDE') : 'CHECKING AI'}
               </span>
               <span className={`${aiStatus.searchGrounding ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : 'bg-slate-100 text-slate-600 border-slate-200'} text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1 border`}>
                 {aiStatus.searchGrounding ? <Globe className="w-3 h-3" /> : <ShieldCheck className="w-3 h-3" />}
                 {aiStatus.searchGrounding ? 'SEARCH GROUNDED' : 'EDUCATIONAL ONLY'}
               </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Specialized Indian stock market & teen finance tutor with Voice Mode
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Auto Read Speech Toggle */}
          <button
            onClick={() => setSpeechSynthesisActive(!speechSynthesisActive)}
            className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
              speechSynthesisActive
                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-white text-slate-500 border-slate-200 hover:text-slate-900'
            }`}
            title={speechSynthesisActive ? 'Auto Read Aloud Active' : 'Enable Auto Read Aloud Voice'}
          >
            {speechSynthesisActive ? <Volume2 className="w-4 h-4 text-emerald-700" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden md:inline text-[11px]">{speechSynthesisActive ? 'Voice ON' : 'Voice OFF'}</span>
          </button>

          {/* Reset Chat */}
          <button
            onClick={handleClearChat}
            className="p-2 rounded-xl bg-white hover:bg-rose-50 text-slate-500 hover:text-rose-600 border border-slate-200 transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-slate-200 bg-amber-50 px-4 py-2 text-[10px] font-bold text-amber-950 sm:px-5">
        <span>Educational simulation only—not investment advice.</span>
        <span>Availability: {aiStatus.checked ? (aiStatus.configured ? 'Gemini connected' : 'offline guide') : 'checking'}</span>
        <span>Web sources: {aiStatus.searchGrounding ? 'enabled when returned' : 'unavailable'}</span>
        {aiStatus.checkedAt && <time dateTime={aiStatus.checkedAt}>Checked {new Date(aiStatus.checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isSpeaking = speakingMsgId === msg.id;

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-extrabold ${
                  isUser
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-900 border border-slate-200 shadow-xs'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-slate-900 text-white font-medium rounded-tr-none shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-900 rounded-tl-none shadow-xs'
                }`}
              >
                <div className="whitespace-pre-line">{msg.text}</div>
                {!isUser && msg.responseMode && (
                  <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-[10px] text-slate-600">
                    <div className="flex flex-wrap items-center justify-between gap-2"><strong className="uppercase tracking-wide text-slate-700">{msg.responseMode === 'gemini-search-grounded' ? 'Search-grounded AI response' : msg.responseMode === 'gemini-no-search' ? 'AI response · no web grounding' : 'Offline educational response'}</strong>{msg.generatedAt && <time dateTime={msg.generatedAt}>{new Date(msg.generatedAt).toLocaleString()}</time>}</div>
                    {msg.sources && msg.sources.length > 0 && <div className="mt-1.5 flex flex-wrap gap-1.5"><span className="font-black">Sources:</span>{msg.sources.map((source, index) => source.url ? <a key={`${source.title}-${index}`} href={source.url} target="_blank" rel="noreferrer" className="text-indigo-700 underline">{source.title}</a> : <span key={`${source.title}-${index}`}>{source.title}</span>)}</div>}
                  </div>
                )}
                
                <div className="mt-2 pt-1 border-t border-slate-200/40 flex items-center justify-between">
                  {!isUser && (
                    <button
                      onClick={() => speakText(msg.text, msg.id)}
                      className={`text-[11px] font-bold flex items-center gap-1 px-2 py-0.5 rounded-md transition-all ${
                        isSpeaking
                          ? 'bg-emerald-200 text-emerald-900 font-extrabold'
                          : 'text-slate-500 hover:text-slate-900 hover:bg-white'
                      }`}
                      title="Read this explanation aloud"
                    >
                      {isSpeaking ? (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-emerald-700 animate-pulse" />
                          <span>Speaking...</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Listen</span>
                        </>
                      )}
                    </button>
                  )}
                  
                  <div
                    className={`text-[10px] ml-auto font-medium ${
                      isUser ? 'text-zinc-200' : 'text-slate-500'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-white text-slate-900 border border-slate-200 flex items-center justify-center shrink-0 shadow-xs">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-slate-200 rounded-3xl rounded-tl-none p-4 text-xs text-slate-500 flex items-center gap-2 shadow-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-slate-900 animate-bounce"></span>
              <span className="w-2 h-2 rounded-full bg-slate-900 animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-2 h-2 rounded-full bg-slate-900 animate-bounce [animation-delay:0.4s]"></span>
              <span>Chanakya is analyzing Dalal Street charts & fundamentals...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompt Chips */}
      <div className="p-3 bg-white border-t border-slate-200 overflow-x-auto scrollbar-none flex gap-2">
        {QUICK_PROMPTS.map((prompt, pIdx) => (
          <button
            key={pIdx}
            onClick={() => handleSendMessage(prompt)}
            className="text-xs bg-slate-50 hover:bg-slate-200 text-zinc-700 hover:text-slate-900 px-3.5 py-1.5 rounded-full border border-slate-200 font-medium transition-all whitespace-nowrap shrink-0"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Form with Voice Mic Integration */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 sm:p-4 bg-white border-t border-slate-200 flex items-center gap-2"
      >
        <div className="relative flex-1 flex items-center">
          <input
            type="text"
            placeholder={isListening ? 'Listening to your voice...' : 'Ask Chanakya Jr. anything about stocks, P/E ratios, risk, or your portfolio...'}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className={`w-full bg-slate-50 border rounded-xl pl-4 pr-11 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-zinc-500 font-medium ${
              isListening ? 'border-rose-400 ring-2 ring-rose-200' : 'border-slate-200'
            }`}
          />
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            className={`absolute right-2 p-1.5 rounded-lg transition-all ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse'
                : 'text-slate-500 hover:text-slate-900 hover:bg-white'
            }`}
            title={isListening ? 'Stop recording voice' : 'Speak with Microphone'}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={!inputText.trim() || isLoading}
          className="px-4 sm:px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-indigo-700 disabled:opacity-40 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">Ask AI</span>
        </button>
      </form>

    </div>
  );
};
