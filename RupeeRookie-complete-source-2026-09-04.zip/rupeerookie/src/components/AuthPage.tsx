import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Sparkles, 
  User, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Phone, 
  GraduationCap, 
  BookOpen, 
  Zap, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  Award, 
  PieChart, 
  AlertCircle,
  HelpCircle,
  BarChart3,
  Flame,
  Check
} from 'lucide-react';
import { useSimulator } from '../context/SimulatorContext';
import { AuthFormData, UserAccount } from '../types';
import { formatINR } from '../utils/formatters';
import { AuthLaunchTransition } from './AuthLaunchTransition';

export const AuthPage: React.FC = () => {
  const { loginUser, registerUser, nseMarketInfo, marketIndices } = useSimulator();

  const [mode, setMode] = useState<'LOGIN' | 'SIGNUP'>('LOGIN');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [cardTilt, setCardTilt] = useState({ x: 0, y: 0 });
  const [launchState, setLaunchState] = useState<{ user: UserAccount; kind: 'new' | 'returning' } | null>(null);
  const [sessionNotice] = useState(() => {
    const reason = localStorage.getItem('rr_logout_reason');
    if (reason) localStorage.removeItem('rr_logout_reason');
    return reason === 'inactive' ? 'For your privacy, you were signed out after seven days without activity. Sign in again to continue.' : '';
  });

  useEffect(() => {
    if (!launchState) return;
    const timer = window.setTimeout(() => window.location.reload(), 2850);
    return () => window.clearTimeout(timer);
  }, [launchState]);

  const handleAuthPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    setCardTilt({ x: ((event.clientY - rect.top) / rect.height - 0.5) * -5, y: ((event.clientX - rect.left) / rect.width - 0.5) * 5 });
  };

  // Sign In state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Sign Up state
  const [formData, setFormData] = useState<AuthFormData>({
    fullName: '',
    email: '',
    username: '',
    password: '',
    phone: '',
    ageGroup: '16-18 (High School Teen)',
    experienceLevel: 'BEGINNER',
  });

  const [agreedTerms, setAgreedTerms] = useState(false);

  // Quick Demo Login helper
  const handleQuickDemoLogin = async () => {
    setErrorMsg('');
    setLoading(true);
    const res = await loginUser('aaravvjain23@gmail.com', 'RookiePass@2026');
    if (res.success && res.user) {
      setLaunchState({ user: res.user, kind: 'returning' });
    } else {
      setLoading(false);
      setErrorMsg(res.message || 'Demo login failed');
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim()) {
      setErrorMsg('Please enter your email address or username');
      return;
    }
    if (!loginPassword) {
      setErrorMsg('Please enter your password');
      return;
    }
    setErrorMsg('');
    setLoading(true);
    const res = await loginUser(loginIdentifier.trim(), loginPassword);
    if (res.success && res.user) {
      setLaunchState({ user: res.user, kind: 'returning' });
    } else {
      setLoading(false);
      setErrorMsg(res.message || 'Invalid credentials. Please try again.');
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) {
      setErrorMsg('Please enter your full name');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMsg('Please provide a valid email address');
      return;
    }
    if (!formData.username.trim()) {
      setErrorMsg('Please choose a username');
      return;
    }
    if (!formData.password || formData.password.length < 8) {
      setErrorMsg('Create a password with at least 8 characters');
      return;
    }
    if (!agreedTerms) {
      setErrorMsg('Please agree to the educational simulator terms');
      return;
    }

    setErrorMsg('');
    setLoading(true);
    const res = await registerUser(formData);
    if (res.success && res.user) {
      setSuccessMsg('Account created successfully! Welcome to Dalal Street.');
      setLaunchState({ user: res.user, kind: 'new' });
    } else {
      setLoading(false);
      setErrorMsg(res.message || 'Failed to create account. Please try again.');
    }
  };

  if (launchState) {
    return <AuthLaunchTransition user={launchState.user} kind={launchState.kind} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      <a href="#main-content" className="skip-link">Skip to sign in</a>
      {/* Top Ticker Marquee Bar */}
      <div className="bg-slate-900 border-b border-indigo-900/50 text-white py-2 text-xs overflow-hidden relative select-none">
        <div className="animate-marquee flex items-center gap-8 whitespace-nowrap">
          <div className="flex items-center gap-8 shrink-0">
            <div className={`flex items-center gap-2 px-3 py-0.5 rounded-full text-[11px] font-black border ${
              nseMarketInfo.isNSEMarketOpen
                ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                : 'bg-rose-500/20 border-rose-400/40 text-rose-300'
            }`}>
              <span className={`h-2 w-2 rounded-full ${nseMarketInfo.isNSEMarketOpen ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`}></span>
              <span>{nseMarketInfo.isNSEMarketOpen ? 'NSE MARKET OPEN' : 'NSE MARKET CLOSED'}</span>
              <span className="opacity-70 font-mono text-[10px]">({nseMarketInfo.nextSessionCountdown})</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-zinc-300 font-bold">
              <span>🕒 IST:</span>
              <span className="text-white">{nseMarketInfo.istTimeString}</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono">
              <span className="text-zinc-300 font-sans font-bold">NIFTY 50:</span>
              <span className="font-bold text-white">{marketIndices?.nifty50?.value ? marketIndices.nifty50.value.toLocaleString('en-IN') : '—'}</span>
              <span className={`text-[11px] font-bold ${marketIndices?.nifty50?.changePercent !== undefined && marketIndices.nifty50.changePercent < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {marketIndices?.nifty50?.changePercent !== undefined ? `${marketIndices.nifty50.changePercent >= 0 ? '+' : ''}${marketIndices.nifty50.changePercent.toFixed(2)}%` : 'Awaiting feed'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-mono">
              <span className="text-zinc-300 font-sans font-bold">SENSEX:</span>
              <span className="font-bold text-white">{marketIndices?.sensex?.value ? marketIndices.sensex.value.toLocaleString('en-IN') : '—'}</span>
              <span className={`text-[11px] font-bold ${marketIndices?.sensex?.changePercent !== undefined && marketIndices.sensex.changePercent < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {marketIndices?.sensex?.changePercent !== undefined ? `${marketIndices.sensex.changePercent >= 0 ? '+' : ''}${marketIndices.sensex.changePercent.toFixed(2)}%` : 'Awaiting feed'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-amber-300 font-bold bg-amber-400/15 px-3 py-0.5 rounded-full border border-amber-400/30">
              <span>💰 ₹10,00,000 Virtual Capital</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Risk-Free Educational Paper Trading</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Authentication Grid */}
      <main id="main-content" tabIndex={-1} className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-10 outline-none">
        <div className="auth-3d-stage max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* LEFT COLUMN: Brand Hero, Educational Value & Feature Showcase (7 cols on lg) */}
          <div className="auth-3d-card lg:col-span-6 space-y-6 text-left" onPointerMove={handleAuthPointerMove} onPointerLeave={() => setCardTilt({ x: 0, y: 0 })} style={{ transform: `rotateX(${cardTilt.x * 0.45}deg) rotateY(${cardTilt.y * 0.45}deg)` }}>
            {/* Brand Logo Header */}
            <div className="flex items-center gap-3">
              <div className="w-13 h-13 rounded-2xl bg-slate-900 border-2 border-[#2B4764] flex items-center justify-center shadow-lg shadow-[#0F172A]/20 shrink-0">
                <div className="relative flex items-center justify-center font-black text-amber-300 text-2xl font-mono">
                  <span>₹</span>
                  <TrendingUp className="w-4 h-4 text-emerald-400 absolute -top-1 -right-1.5 stroke-[3]" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                    Rupee<span className="text-amber-600">Rookie</span>
                  </h1>
                  <span className="bg-emerald-100 text-emerald-900 border border-emerald-300 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    NSE DALAL STREET
                  </span>
                </div>
                <p className="text-xs sm:text-sm font-semibold text-slate-500">
                  Paper Trading Simulator & Teen Investor Academy
                </p>
              </div>
            </div>

            {/* Hero Copy */}
            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-snug">
                Master Dalal Street with <span className="text-indigo-600">₹10,00,000</span> in Virtual Money.
              </h2>
              <p className="text-xs sm:text-sm text-zinc-700 leading-relaxed font-medium">
                Practise with 75+ curated Indian equities, indicative market quotes, interactive charts, lesson quizzes, and Chanakya AI explanations—all without using real money.
              </p>
            </div>

            {/* Feature Cards Grid */}
            <div className="auth-3d-layer-soft grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-900 shrink-0">
                  <PieChart className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">₹10 Lakhs Virtual Fund</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Build a real portfolio with zero financial risk</p>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-100 text-emerald-900 shrink-0">
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">75+ Indian Equities</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Indicative quotes, technicals & fundamental ratios</p>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-start gap-3">
                <div className="p-2 rounded-xl bg-indigo-100 text-indigo-900 shrink-0">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">12 Interactive Lessons</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Gamified modules, quizzes & XP achievements</p>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-start gap-3">
                <div className="p-2 rounded-xl bg-orange-100 text-orange-900 shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">Chanakya AI Mentor</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Instant AI risk analysis and smart portfolio coaching</p>
                </div>
              </div>
            </div>

            <div className="auth-3d-layer relative overflow-hidden rounded-3xl border border-indigo-300 bg-gradient-to-br from-indigo-950 via-slate-950 to-violet-950 p-4 text-white shadow-xl" aria-label="Interactive learning journey preview">
              <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-indigo-500/25 blur-2xl" />
              <div className="relative flex items-center justify-between gap-4"><div><p className="text-[10px] font-black uppercase tracking-[0.16em] text-indigo-300">Your learning cockpit</p><h3 className="mt-1 text-sm font-black">Learn → Plan → Practise → Reflect</h3><p className="mt-1 text-[11px] leading-relaxed text-slate-300">Progress is built from thoughtful decisions, not how often you trade.</p></div><div className="relative h-20 w-24 shrink-0"><div className="absolute inset-x-2 top-0 rotate-[-7deg] rounded-xl border border-indigo-300/40 bg-indigo-500/20 p-2 text-[9px] font-black backdrop-blur">LEARN</div><div className="absolute inset-x-1 top-6 rotate-[5deg] rounded-xl border border-emerald-300/40 bg-emerald-500/20 p-2 text-[9px] font-black backdrop-blur">PRACTISE</div><div className="absolute inset-x-0 top-12 rotate-[-2deg] rounded-xl border border-amber-300/40 bg-amber-500/20 p-2 text-[9px] font-black backdrop-blur">REFLECT</div></div></div>
            </div>

            {/* Quick Demo Access Box */}
            <div className="bg-white border-2 border-amber-300/80 rounded-2xl p-4 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-slate-900 text-amber-300 flex items-center justify-center font-black text-xs shrink-0">
                    A
                  </div>
                  <div>
                    <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <span>Quick Demo Pass</span>
                      <span className="text-[9px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-extrabold uppercase">
                        Instant
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-600">
                      Sign in as <strong>Aarav Jain</strong> (@aarav_trader)
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  id="quick-demo-login-btn"
                  onClick={handleQuickDemoLogin}
                  disabled={loading}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-indigo-900 text-amber-300 hover:text-amber-200 text-xs font-black rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>1-Click Demo Login</span>
                </button>
              </div>
            </div>

            {/* Safe Educational Footer */}
            <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Educational simulation only. Market data may be delayed and nothing here is investment advice.</span>
            </div>
          </div>

          {/* RIGHT COLUMN: Dedicated Login / Signup Card (6 cols on lg) */}
          <div className="lg:col-span-6 auth-3d-card" onPointerMove={handleAuthPointerMove} onPointerLeave={() => setCardTilt({ x: 0, y: 0 })} style={{ transform: `rotateX(${cardTilt.x}deg) rotateY(${cardTilt.y}deg)` }}>
            <div className="auth-3d-layer bg-white border-2 border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xl text-left">
              
              {/* Tab Selector: Sign In vs Create Account */}
              <div className="flex items-center p-1 bg-slate-50 rounded-2xl border border-slate-200 mb-6">
                <button
                  type="button"
                  id="tab-btn-login"
                  onClick={() => { setMode('LOGIN'); setErrorMsg(''); setSuccessMsg(''); }}
                  className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer text-center ${
                    mode === 'LOGIN'
                      ? 'bg-slate-900 text-white shadow-md'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  id="tab-btn-signup"
                  onClick={() => { setMode('SIGNUP'); setErrorMsg(''); setSuccessMsg(''); }}
                  className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer text-center ${
                    mode === 'SIGNUP'
                      ? 'bg-slate-900 text-white shadow-md'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Create Student Account
                </button>
              </div>

              {/* Status & Error Messages */}
              {sessionNotice && (
                <div role="status" aria-live="polite" className="mb-5 flex items-start gap-2.5 rounded-2xl border border-amber-300 bg-amber-50 p-3.5 text-xs text-amber-900">
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
                  <span className="font-bold">{sessionNotice}</span>
                </div>
              )}

              {errorMsg && (
                <div role="alert" aria-live="assertive" className="mb-5 bg-rose-50 border border-rose-300 rounded-2xl p-3.5 flex items-start gap-2.5 text-rose-800 text-xs">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-bold">{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div role="status" aria-live="polite" className="mb-5 bg-emerald-50 border border-emerald-300 rounded-2xl p-3.5 flex items-start gap-2.5 text-emerald-800 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="font-bold">{successMsg}</span>
                </div>
              )}

              {/* VIEW A: SIGN IN FORM */}
              {mode === 'LOGIN' && (
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="login-identifier-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
                      Email or Username
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        id="login-identifier-input"
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        placeholder="aaravvjain23@gmail.com or aarav_trader"
                        autoComplete="username"
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 transition-all"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label htmlFor="login-password-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider">
                        Password
                      </label>
                    </div>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        id="login-password-input"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="Enter your password"
                        autoComplete="current-password"
                        required
                        className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                        className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-900"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      id="login-submit-btn"
                      disabled={loading}
                      className="w-full py-3.5 px-4 bg-slate-900 hover:bg-indigo-900 text-white rounded-xl font-extrabold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {loading ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>Sign In to Dalal Street</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>

                  <div className="pt-3 border-t border-slate-200/60 text-center">
                    <p className="text-xs text-slate-500">
                      Don't have an account yet?{' '}
                      <button
                        type="button"
                        onClick={() => { setMode('SIGNUP'); setErrorMsg(''); }}
                        className="text-slate-900 font-black underline hover:text-indigo-600 cursor-pointer ml-1"
                      >
                        Create Free Student Account
                      </button>
                    </p>
                  </div>
                </form>
              )}

              {/* VIEW B: SIGN UP FORM */}
              {mode === 'SIGNUP' && (
                <form onSubmit={handleSignupSubmit} className="space-y-3.5">
                  <div>
                    <label htmlFor="signup-fullname-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                      Full Name *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        id="signup-fullname-input"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        autoComplete="name"
                        placeholder="e.g. Aarav Jain"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="signup-email-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Email Address *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                          <Mail className="w-4 h-4" />
                        </div>
                        <input
                          type="email"
                          id="signup-email-input"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          autoComplete="email"
                          placeholder="aarav@school.edu"
                          className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="signup-username-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Username *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                          <span className="text-xs font-bold font-mono">@</span>
                        </div>
                        <input
                          type="text"
                          id="signup-username-input"
                          value={formData.username}
                          onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })}
                          autoComplete="username"
                          minLength={3}
                          placeholder="aarav_invests"
                          className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="signup-password-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Password *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                          <Lock className="w-4 h-4" />
                        </div>
                        <input
                          type={showPassword ? 'text' : 'password'}
                          id="signup-password-input"
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          placeholder="At least 8 characters"
                          autoComplete="new-password"
                          minLength={8}
                          maxLength={128}
                          required
                          className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-900"
                        >
                          {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="signup-phone-input" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Phone (Optional)
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                          <Phone className="w-4 h-4" />
                        </div>
                        <input
                          type="tel"
                          id="signup-phone-input"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          autoComplete="tel"
                          placeholder="+91 98765 43210"
                          className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder-[#64748B]/70 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Age Group & Experience */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="signup-agegroup-select" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Student / Age Cohort
                      </label>
                      <select
                        id="signup-agegroup-select"
                        value={formData.ageGroup}
                        onChange={(e) => setFormData({ ...formData, ageGroup: e.target.value })}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                      >
                        <option value="13-15 (Middle School Teen)">13-15 (Middle School Teen)</option>
                        <option value="16-18 (High School Teen)">16-18 (High School Teen)</option>
                        <option value="18-21 (College Student)">18-21 (College Student)</option>
                        <option value="21+ (Adult / Educator)">21+ (Adult / Educator)</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="signup-experience-select" className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Stock Market Experience
                      </label>
                      <select
                        id="signup-experience-select"
                        value={formData.experienceLevel}
                        onChange={(e) => setFormData({ ...formData, experienceLevel: e.target.value as any })}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                      >
                        <option value="BEGINNER">Beginner (Starting Fresh)</option>
                        <option value="INTERMEDIATE">Intermediate (Know Basics)</option>
                        <option value="ADVANCED">Advanced (Active Trader)</option>
                      </select>
                    </div>
                  </div>

                  {/* Educational Terms Checkbox */}
                  <div className="pt-1">
                    <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-500">
                      <input
                        type="checkbox"
                        checked={agreedTerms}
                        onChange={(e) => setAgreedTerms(e.target.checked)}
                        required
                        className="mt-0.5 rounded border-slate-200 text-slate-900 focus:ring-indigo-600"
                      />
                      <span className="leading-snug">
                        I understand that <strong className="text-slate-900">RupeeRookie</strong> is an educational paper trading simulator with ₹10,00,000 in virtual funds and zero real money risk.
                      </span>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      id="signup-submit-btn"
                      disabled={loading}
                      className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-extrabold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {loading ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Create Account & Get ₹10,00,000 Capital</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 text-center">
                    <p className="text-xs text-slate-500">
                      Already have an account?{' '}
                      <button
                        type="button"
                        onClick={() => { setMode('LOGIN'); setErrorMsg(''); }}
                        className="text-slate-900 font-black underline hover:text-indigo-600 cursor-pointer ml-1"
                      >
                        Sign In here
                      </button>
                    </p>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>
      </main>

      {/* Auth Page Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="font-bold text-slate-900">RupeeRookie</span>
            <span>— Educational NSE Financial Simulator</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Educational use only</span>
            <span>•</span>
            <span>Virtual ₹10 Lakhs Sandbox</span>
            <span>•</span>
            <span>Not investment advice</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
