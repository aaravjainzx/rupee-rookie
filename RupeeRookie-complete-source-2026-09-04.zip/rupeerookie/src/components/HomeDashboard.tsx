import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Check,
  CheckCircle2,
  Clock3,
  Download,
  GraduationCap,
  PieChart,
  ShieldCheck,
  Sparkles,
  Target,
  Wallet,
  Lightbulb,
  CalendarRange,
  MessageSquare,
  Megaphone,
} from 'lucide-react';
import { useSimulator } from '../context/SimulatorContext';
import { formatINR, formatPercent } from '../utils/formatters';
import type { AppTabType } from './Header';
import { useAccessibility } from '../context/AccessibilityContext';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface MissionState {
  checked: boolean[];
  takeaway: string;
  completed: boolean;
}

type MissionDifficulty = 'AUTO' | 'GENTLE' | 'STANDARD' | 'ADVANCED';

const getIstDateKey = () => new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Kolkata',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
}).format(new Date());

export const HomeDashboard: React.FC<{ setActiveTab: (tab: AppTabType) => void }> = ({ setActiveTab }) => {
  const { settings } = useAccessibility();
  const {
    currentUser,
    portfolioValue,
    cashBalance,
    totalPnL,
    totalPnLPercent,
    holdings,
    orders,
    completedLessonIds,
    userXP,
    userLevel,
    nseMarketInfo,
    earnXP,
  } = useSimulator();

  const missionKey = `rr_daily_mission:${currentUser?.id || 'guest'}:${getIstDateKey()}`;
  const [mission, setMission] = useState<MissionState>(() => {
    try {
      return JSON.parse(localStorage.getItem(missionKey) || '') as MissionState;
    } catch {
      return { checked: [false, false, false], takeaway: '', completed: false };
    }
  });
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [offlineReady, setOfflineReady] = useState(false);
  const [missionDifficulty, setMissionDifficulty] = useState<MissionDifficulty>(() => (localStorage.getItem(`rr_mission_difficulty:${currentUser?.id || 'guest'}`) as MissionDifficulty) || 'AUTO');
  const [feedback, setFeedback] = useState<'HELPFUL' | 'NOT_YET' | null>(() => localStorage.getItem(`rr_home_feedback:${currentUser?.id || 'guest'}:${getIstDateKey()}`) as 'HELPFUL' | 'NOT_YET' | null);

  useEffect(() => { localStorage.setItem(`rr_mission_difficulty:${currentUser?.id || 'guest'}`, missionDifficulty); }, [missionDifficulty, currentUser?.id]);

  useEffect(() => {
    localStorage.setItem(missionKey, JSON.stringify(mission));
  }, [mission, missionKey]);

  useEffect(() => {
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', onInstallPrompt);
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(() => setOfflineReady(true)).catch(() => setOfflineReady(false));
    }
    return () => window.removeEventListener('beforeinstallprompt', onInstallPrompt);
  }, []);

  const missionProgress = mission.checked.filter(Boolean).length;
  const greetingName = currentUser?.fullName?.split(' ')[0] || 'Investor';
  const executedTrades = orders.filter((order) => order.status === 'EXECUTED').length;
  const dayIndex = useMemo(() => Math.abs([...getIstDateKey()].reduce((total, character) => total + character.charCodeAt(0), 0)), []);
  const dailyConcepts = [
    { title: 'Diversification is about causes, not count', detail: 'Five companies can still be concentrated if they depend on the same sector, customer or economic event.' },
    { title: 'A price and a value are different', detail: 'Market price is what participants agree today; value depends on future cash flows, risk and expectations.' },
    { title: 'Doing nothing can be a decision', detail: 'A calm investor can observe, learn and wait. Activity is not the same as progress.' },
    { title: 'Risk begins with position size', detail: 'A good idea can still hurt a portfolio when one position is allowed to become too large.' },
    { title: 'A thesis needs an invalidation rule', detail: 'Write what evidence would prove an idea wrong before emotions and price movement take over.' },
  ];
  const dailyConcept = dailyConcepts[dayIndex % dailyConcepts.length];
  const weeklySummary = useMemo(() => {
    const executed = orders.filter((order) => order.status === 'EXECUTED');
    const recent = executed.filter((order) => Date.now() - new Date(order.timestamp).getTime() <= 7 * 24 * 60 * 60 * 1000);
    const activity = recent.length === 0
      ? 'No trades this week—and that is completely fine. Your learning activity still counts.'
      : `${recent.length} simulated trade${recent.length === 1 ? '' : 's'} this week. Review the journal before repeating a setup.`;
    return { activity, lessons: completedLessonIds.length, riskReviews: Object.keys(holdings).length ? 'Portfolio exposure is ready for a concentration review.' : 'No portfolio exposure is currently active.' };
  }, [completedLessonIds.length, holdings, orders]);

  const saveFeedback = (value: 'HELPFUL' | 'NOT_YET') => {
    setFeedback(value);
    localStorage.setItem(`rr_home_feedback:${currentUser?.id || 'guest'}:${getIstDateKey()}`, value);
  };

  const concentrationNote = useMemo(() => {
    const holdingValues = Object.values(holdings).map((holding) => {
      const value = holding.quantity * holding.avgBuyPrice;
      return { symbol: holding.symbol, value };
    });
    const total = holdingValues.reduce((sum, holding) => sum + holding.value, 0);
    if (total === 0) return 'No portfolio risk yet. Learn the basics before making your first simulated decision.';
    const largest = [...holdingValues].sort((a, b) => b.value - a.value)[0];
    const weight = (largest.value / total) * 100;
    return weight > 35
      ? `${largest.symbol} is about ${weight.toFixed(0)}% of invested value. Review concentration before adding exposure.`
      : 'No single holding currently exceeds the 35% concentration warning level.';
  }, [holdings]);

  const toggleMissionStep = (index: number) => {
    if (index === 2 && mission.takeaway.trim().length < 8) return;
    setMission((previous) => {
      if (previous.completed) return previous;
      const checked = [...previous.checked];
      checked[index] = !checked[index];
      const completed = checked.every(Boolean);
      if (completed) earnXP(25, `Completed daily learning mission ${getIstDateKey()}`);
      return { ...previous, checked, completed };
    });
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === 'accepted') setInstallPrompt(null);
  };

  const resolvedDifficulty = missionDifficulty === 'AUTO'
    ? currentUser?.experienceLevel === 'ADVANCED' ? 'ADVANCED' : currentUser?.experienceLevel === 'INTERMEDIATE' ? 'STANDARD' : 'GENTLE'
    : missionDifficulty;
  const missionStepsByDifficulty = {
    GENTLE: [
      { title: 'Learn one idea', detail: 'Read the recommended first Academy concept.', time: '2 min', action: () => setActiveTab('academy') },
      { title: 'Find one risk', detail: 'Notice which holding or sector could dominate.', time: '2 min', action: () => setActiveTab('portfolio') },
      { title: 'Explain it simply', detail: 'Write one sentence in your own words. No trade required.', time: '1 min', action: undefined },
    ],
    STANDARD: [
      { title: 'Compare two ideas', detail: 'Read a lesson and one historical case.', time: '2 min', action: () => setActiveTab('academy') },
      { title: 'Run a risk check', detail: 'Test a sector fall and review concentration.', time: '2 min', action: () => setActiveTab('portfolio') },
      { title: 'Record a rule', detail: 'Write one rule you could follow next time.', time: '1 min', action: undefined },
    ],
    ADVANCED: [
      { title: 'Challenge a thesis', detail: 'List what evidence could make an idea wrong.', time: '2 min', action: () => setActiveTab('academy') },
      { title: 'Stress the portfolio', detail: 'Compare concentration and scenario impact.', time: '2 min', action: () => setActiveTab('portfolio') },
      { title: 'Define a decision rule', detail: 'Write a specific, testable rule. No trade required.', time: '1 min', action: undefined },
    ],
  } as const;
  const hindiMissionSteps = {
    GENTLE: [
      { title: 'एक विचार समझें', detail: 'अकादमी में सुझाया गया छोटा पाठ पढ़ें।', time: '2 मिनट', action: () => setActiveTab('academy') },
      { title: 'एक जोखिम पहचानें', detail: 'देखें कि कौन-सा स्टॉक या सेक्टर पोर्टफोलियो पर अधिक प्रभाव डाल सकता है।', time: '2 मिनट', action: () => setActiveTab('portfolio') },
      { title: 'अपने शब्दों में लिखें', detail: 'केवल एक वाक्य लिखें। ट्रेड करना आवश्यक नहीं है।', time: '1 मिनट', action: undefined },
    ],
    STANDARD: [
      { title: 'दो विचारों की तुलना करें', detail: 'एक पाठ और एक ऐतिहासिक केस स्टडी देखें।', time: '2 मिनट', action: () => setActiveTab('academy') },
      { title: 'जोखिम जाँच करें', detail: 'सेक्टर में गिरावट का परीक्षण करके एकाग्रता समझें।', time: '2 मिनट', action: () => setActiveTab('portfolio') },
      { title: 'एक नियम लिखें', detail: 'अगली बार पालन करने के लिए सरल नियम बनाएँ।', time: '1 मिनट', action: undefined },
    ],
    ADVANCED: [
      { title: 'निवेश विचार को चुनौती दें', detail: 'कौन-सा प्रमाण आपके निवेश विचार को गलत सिद्ध करेगा?', time: '2 मिनट', action: () => setActiveTab('academy') },
      { title: 'पोर्टफोलियो का दबाव परीक्षण करें', detail: 'एकाग्रता और परिदृश्य के प्रभाव की तुलना करें।', time: '2 मिनट', action: () => setActiveTab('portfolio') },
      { title: 'निर्णय का नियम बनाएँ', detail: 'स्पष्ट और जाँचने योग्य नियम लिखें। ट्रेड आवश्यक नहीं है।', time: '1 मिनट', action: undefined },
    ],
  } as const;
  const missionSteps = settings.learningLanguage === 'HINDI' ? hindiMissionSteps[resolvedDifficulty] : missionStepsByDifficulty[resolvedDifficulty];

  return (
    <div className="space-y-4 pb-4 sm:space-y-6">
      <section className="overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 p-5 text-white shadow-xl sm:p-7">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-indigo-300">Today at RupeeRookie</p>
            <h1 className="mt-1 text-2xl font-black tracking-tight">Namaste, {greetingName}</h1>
            <p className="mt-1 max-w-xl text-xs leading-relaxed text-slate-300">{settings.learningLanguage === 'HINDI' ? 'केवल 5 शांत मिनटों में बेहतर निर्णय क्षमता बनाएँ। सीखने की प्रगति, ट्रेड की संख्या से अधिक महत्वपूर्ण है।' : 'Build judgment in five calm minutes. Learning progress matters more than trade count.'}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-right backdrop-blur">
            <p className="text-[9px] font-bold uppercase text-slate-400">Level {userLevel.level}</p>
            <p className="font-mono text-sm font-black text-amber-300">{userXP} XP</p>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <div className="rounded-2xl border border-white/10 bg-white/8 p-3">
            <Wallet className="h-4 w-4 text-indigo-300" />
            <p className="mt-2 text-[9px] font-bold uppercase text-slate-400">Portfolio</p>
            <p className="truncate font-mono text-sm font-black">{formatINR(portfolioValue)}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/8 p-3">
            <BarChart3 className="h-4 w-4 text-emerald-300" />
            <p className="mt-2 text-[9px] font-bold uppercase text-slate-400">Net P&amp;L</p>
            <p className={`font-mono text-sm font-black ${totalPnL >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>{formatPercent(totalPnLPercent)}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/8 p-3">
            <GraduationCap className="h-4 w-4 text-amber-300" />
            <p className="mt-2 text-[9px] font-bold uppercase text-slate-400">Lessons</p>
            <p className="font-mono text-sm font-black">{completedLessonIds.length} complete</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/8 p-3">
            <Clock3 className={`h-4 w-4 ${nseMarketInfo.isNSEMarketOpen ? 'text-emerald-300' : 'text-slate-300'}`} />
            <p className="mt-2 text-[9px] font-bold uppercase text-slate-400">NSE status</p>
            <p className="text-sm font-black">{nseMarketInfo.isNSEMarketOpen ? 'Open' : 'Closed'}</p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <section className="rounded-3xl border border-indigo-200 bg-white p-5 shadow-sm dark:border-indigo-900 dark:bg-slate-900 lg:col-span-7">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-indigo-600" />
                <h2 className="text-base font-black text-slate-950 dark:text-white">{settings.learningLanguage === 'HINDI' ? 'आज का 5-मिनट मिशन' : 'Your five-minute mission'}</h2>
              </div>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{settings.learningLanguage === 'HINDI' ? 'एक पाठ, एक जोखिम जाँच और एक चिंतन। कोई ट्रेड आवश्यक नहीं है।' : 'One lesson, one risk check, one reflection. Zero trades required.'}</p>
            </div>
            <div className="flex items-center gap-2"><label className="sr-only" htmlFor="mission-difficulty">Mission difficulty</label><select id="mission-difficulty" value={missionDifficulty} onChange={(event) => setMissionDifficulty(event.target.value as MissionDifficulty)} disabled={mission.completed} className="rounded-xl border border-indigo-200 bg-indigo-50 px-2 py-1 text-[10px] font-black text-indigo-900 dark:border-indigo-800 dark:bg-indigo-950 dark:text-indigo-200"><option value="AUTO">Auto · {resolvedDifficulty.toLowerCase()}</option><option value="GENTLE">Gentle</option><option value="STANDARD">Standard</option><option value="ADVANCED">Advanced</option></select><span className="rounded-full bg-indigo-100 px-2.5 py-1 text-[10px] font-black text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">{missionProgress}/3</span></div>
          </div>

          <div className="mt-4 space-y-2.5">
            {missionSteps.map((step, index) => (
              <div key={step.title} className={`rounded-2xl border p-3 ${mission.checked[index] ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/30' : 'border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800'}`}>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => toggleMissionStep(index)}
                    aria-label={`${mission.checked[index] ? 'Mark incomplete' : 'Mark complete'}: ${step.title}`}
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border ${mission.checked[index] ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-300 bg-white text-slate-400 dark:border-slate-600 dark:bg-slate-900'}`}
                  >
                    {mission.checked[index] ? <Check className="h-4 w-4" /> : <span className="text-[11px] font-black">{index + 1}</span>}
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-xs font-extrabold text-slate-900 dark:text-white">{step.title}</h3>
                      <span className="text-[10px] font-bold text-slate-400">{step.time}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">{step.detail}</p>
                  </div>
                  {step.action && !mission.checked[index] && (
                    <button type="button" onClick={step.action} className="rounded-xl p-2 text-indigo-600" aria-label={`Open ${step.title}`}><ArrowRight className="h-4 w-4" /></button>
                  )}
                </div>
                {index === 2 && (
                  <textarea
                    value={mission.takeaway}
                    onChange={(event) => setMission((previous) => ({ ...previous, takeaway: event.target.value }))}
                    disabled={mission.completed}
                    placeholder={settings.learningLanguage === 'HINDI' ? 'आज मैंने सीखा कि…' : 'Today I learned that…'}
                    maxLength={180}
                    className="mt-3 min-h-20 w-full resize-none rounded-xl border border-slate-200 bg-white p-3 text-xs outline-none focus:border-indigo-500 disabled:opacity-70 dark:border-slate-700 dark:bg-slate-900"
                  />
                )}
              </div>
            ))}
          </div>
          {mission.completed && (
            <div className="mt-3 flex items-center gap-2 rounded-2xl bg-emerald-100 p-3 text-xs font-extrabold text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200">
              <CheckCircle2 className="h-4 w-4" /> {settings.learningLanguage === 'HINDI' ? 'मिशन पूरा · +25 XP · आज अतिरिक्त ट्रेड की आवश्यकता नहीं' : 'Mission complete · +25 XP · no extra trading needed today'}
            </div>
          )}
        </section>

        <div className="space-y-4 lg:col-span-5">
          <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-emerald-600" /><h2 className="text-sm font-black">Portfolio risk check</h2></div>
            <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">{concentrationNote}</p>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-slate-50 p-2 dark:bg-slate-800"><p className="text-[9px] uppercase text-slate-400">Holdings</p><p className="font-mono text-sm font-black">{Object.keys(holdings).length}</p></div>
              <div className="rounded-xl bg-slate-50 p-2 dark:bg-slate-800"><p className="text-[9px] uppercase text-slate-400">Trades</p><p className="font-mono text-sm font-black">{executedTrades}</p></div>
              <div className="rounded-xl bg-slate-50 p-2 dark:bg-slate-800"><p className="text-[9px] uppercase text-slate-400">Cash</p><p className="truncate font-mono text-xs font-black">{formatINR(cashBalance, false)}</p></div>
            </div>
            <button type="button" onClick={() => setActiveTab('portfolio')} className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-black text-white dark:bg-indigo-600">Open risk heatmap <ArrowRight className="h-3.5 w-3.5" /></button>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2"><Download className="h-5 w-5 text-indigo-600" /><h2 className="text-sm font-black">RupeeRookie on mobile</h2></div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Install the app and keep Academy lessons available after they are prepared for offline use.</p>
            {installPrompt ? (
              <button type="button" onClick={installApp} className="mt-3 w-full rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-black text-white">Install mobile app</button>
            ) : (
              <div className="mt-3 flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-xs font-bold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                {offlineReady ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> : <Sparkles className="h-4 w-4 text-amber-500" />}
                {offlineReady ? 'Offline Academy support is ready on this device.' : 'Open in a supported mobile browser to install.'}
              </div>
            )}
          </section>
        </div>
      </div>

      <section className="grid grid-cols-1 gap-4 lg:grid-cols-12" aria-label="Daily insight and weekly report">
        <article className="rounded-3xl border border-violet-200 bg-gradient-to-br from-white to-violet-50 p-5 shadow-sm dark:border-violet-900 dark:from-slate-900 dark:to-violet-950/30 lg:col-span-7">
          <div className="flex items-start gap-3">
            <div className="rounded-2xl bg-violet-100 p-2.5 text-violet-700 dark:bg-violet-950 dark:text-violet-300"><Lightbulb className="h-5 w-5" /></div>
            <div className="min-w-0"><p className="text-xs font-black uppercase tracking-wide text-violet-700 dark:text-violet-300">Today&apos;s market concept</p><h2 className="mt-1 text-base font-black text-slate-950 dark:text-white">{dailyConcept.title}</h2><p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{dailyConcept.detail}</p></div>
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-violet-200 pt-3 dark:border-violet-900">
            <p className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300"><MessageSquare className="h-4 w-4" /> Was this explanation useful?</p>
            <div className="flex gap-2"><button type="button" onClick={() => saveFeedback('HELPFUL')} aria-pressed={feedback === 'HELPFUL'} className={`min-h-10 rounded-xl border px-3 text-xs font-black ${feedback === 'HELPFUL' ? 'border-emerald-500 bg-emerald-100 text-emerald-900' : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'}`}>Yes, helpful</button><button type="button" onClick={() => saveFeedback('NOT_YET')} aria-pressed={feedback === 'NOT_YET'} className={`min-h-10 rounded-xl border px-3 text-xs font-black ${feedback === 'NOT_YET' ? 'border-amber-500 bg-amber-100 text-amber-950' : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'}`}>Needs clarity</button></div>
          </div>
        </article>
        <article className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 lg:col-span-5">
          <div className="flex items-center gap-2"><CalendarRange className="h-5 w-5 text-emerald-600" /><h2 className="text-sm font-black">Your weekly learning report</h2></div>
          <div className="mt-3 space-y-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300"><p>{weeklySummary.activity}</p><p><strong>{weeklySummary.lessons}</strong> Academy lesson{weeklySummary.lessons === 1 ? '' : 's'} completed overall.</p><p>{weeklySummary.riskReviews}</p></div>
          <button type="button" onClick={() => setActiveTab('journal')} className="mt-4 min-h-11 w-full rounded-xl bg-slate-900 px-4 text-xs font-black text-white dark:bg-indigo-600">Open weekly reflection</button>
        </article>
      </section>

      <details className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <summary className="flex min-h-10 cursor-pointer list-none items-center gap-2 text-xs font-black text-slate-800 dark:text-slate-100"><Megaphone className="h-4 w-4 text-indigo-600" /> What&apos;s new in RupeeRookie</summary>
        <ul className="mt-2 grid gap-2 border-t border-slate-100 pt-3 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300 sm:grid-cols-3"><li>• Faster page loading with route-shaped skeletons.</li><li>• Clearer quote sources and educational-model labels.</li><li>• Improved Hindi summaries, risk checks and genuine progress.</li></ul>
      </details>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { title: 'Markets', detail: 'Discover companies', icon: BarChart3, tab: 'screener' as AppTabType },
          { title: 'Portfolio', detail: 'Review allocation', icon: PieChart, tab: 'portfolio' as AppTabType },
          { title: 'Academy', detail: 'Continue lessons', icon: BookOpen, tab: 'academy' as AppTabType },
          { title: 'Progress', detail: 'XP and badges', icon: GraduationCap, tab: 'badges' as AppTabType },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <button key={item.title} type="button" onClick={() => setActiveTab(item.tab)} className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition-transform active:scale-[0.98] dark:border-slate-800 dark:bg-slate-900">
              <Icon className="h-5 w-5 text-indigo-600" />
              <p className="mt-3 text-xs font-black text-slate-900 dark:text-white">{item.title}</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">{item.detail}</p>
            </button>
          );
        })}
      </section>
    </div>
  );
};
