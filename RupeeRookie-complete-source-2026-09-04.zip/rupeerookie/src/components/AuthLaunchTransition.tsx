import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { BarChart3, BookOpen, ShieldCheck, Sparkles, Target, Wallet } from 'lucide-react';
import type { UserAccount } from '../types';

interface AuthLaunchTransitionProps {
  user: UserAccount;
  kind: 'new' | 'returning';
}

const NEW_USER_STEPS = ['Creating your learning profile…', 'Preparing ₹10,00,000 virtual capital…', 'Getting your guided tour ready…'];
const RETURNING_USER_STEPS = ['Restoring your private workspace…', 'Refreshing learning progress…', 'Choosing today’s tip…'];

export const AuthLaunchTransition: React.FC<AuthLaunchTransitionProps> = ({ user, kind }) => {
  const [step, setStep] = useState(0);
  const reduceMotion = useReducedMotion();
  const messages = kind === 'new' ? NEW_USER_STEPS : RETURNING_USER_STEPS;

  useEffect(() => {
    const timers = [
      window.setTimeout(() => setStep(1), 850),
      window.setTimeout(() => setStep(2), 1700),
    ];
    return () => timers.forEach(window.clearTimeout);
  }, []);

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#060918] px-4 py-10 text-white" aria-labelledby="launch-title">
      <div className="absolute inset-0 opacity-35" style={{ backgroundImage: 'linear-gradient(rgba(99,102,241,.14) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,.14) 1px, transparent 1px)', backgroundSize: '42px 42px', transform: 'perspective(500px) rotateX(62deg) scale(1.8) translateY(18%)', transformOrigin: 'center bottom' }} />
      <motion.div className="absolute -left-24 top-12 h-72 w-72 rounded-full bg-indigo-600/25 blur-3xl" animate={reduceMotion ? undefined : { x: [0, 55, 0], y: [0, 35, 0] }} transition={{ duration: 7, repeat: Infinity }} />
      <motion.div className="absolute -right-20 bottom-8 h-80 w-80 rounded-full bg-violet-600/20 blur-3xl" animate={reduceMotion ? undefined : { x: [0, -45, 0], y: [0, -30, 0] }} transition={{ duration: 8, repeat: Infinity }} />

      <section className="relative z-10 w-full max-w-3xl text-center" role="status" aria-live="polite">
        <div className="mx-auto mb-7 h-52 w-52 [perspective:900px] sm:h-64 sm:w-64">
          <motion.div
            className="relative h-full w-full [transform-style:preserve-3d]"
            animate={reduceMotion ? undefined : { rotateY: 360, rotateX: [8, -8, 8] }}
            transition={{ rotateY: { duration: 10, repeat: Infinity, ease: 'linear' }, rotateX: { duration: 4, repeat: Infinity, ease: 'easeInOut' } }}
          >
            <div className="absolute inset-8 rounded-full border border-indigo-400/50 shadow-[0_0_55px_rgba(99,102,241,.35)]" />
            <div className="absolute inset-14 rounded-full border border-violet-300/35 [transform:rotateX(68deg)]" />
            <div className="absolute inset-14 rounded-full border border-cyan-300/30 [transform:rotateY(68deg)]" />
            <div className="absolute inset-[34%] flex items-center justify-center rounded-3xl border border-white/20 bg-gradient-to-br from-indigo-500 to-violet-700 text-4xl font-black shadow-2xl shadow-indigo-500/40 [transform:translateZ(38px)]">₹</div>

            {[
              { Icon: BarChart3, label: 'Markets', position: 'left-0 top-12', depth: 'translateZ(24px)' },
              { Icon: BookOpen, label: 'Academy', position: 'right-0 top-20', depth: 'translateZ(42px)' },
              { Icon: ShieldCheck, label: 'Risk', position: 'bottom-7 left-8', depth: 'translateZ(32px)' },
            ].map(({ Icon, label, position, depth }) => (
              <motion.div key={label} className={`absolute ${position} rounded-2xl border border-white/15 bg-slate-900/80 p-3 shadow-xl backdrop-blur-xl`} style={{ transform: depth }} animate={reduceMotion ? undefined : { y: [0, -8, 0] }} transition={{ duration: 2.4, repeat: Infinity, delay: label.length * 0.08 }}>
                <Icon className="mx-auto h-5 w-5 text-indigo-300" />
                <span className="mt-1 block text-[9px] font-black uppercase tracking-wider text-slate-300">{label}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}>
          <div className="mx-auto mb-3 flex w-fit items-center gap-2 rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.18em] text-indigo-200">
            <Sparkles className="h-3.5 w-3.5" /> {kind === 'new' ? 'Account ready' : 'Welcome back'}
          </div>
          <h1 id="launch-title" className="text-2xl font-black tracking-tight sm:text-4xl">
            {kind === 'new' ? `Welcome, ${user.fullName.split(' ')[0]}!` : `Good to see you, ${user.fullName.split(' ')[0]}.`}
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-slate-300 sm:text-base">
            {messages[step]}
          </p>
        </motion.div>

        <div className="mx-auto mt-7 max-w-md">
          <div className="h-2 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
            <motion.div className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-violet-500" initial={{ width: '4%' }} animate={{ width: '100%' }} transition={{ duration: 2.65, ease: 'easeInOut' }} />
          </div>
          <div className="mt-3 flex items-center justify-center gap-4 text-[10px] font-bold text-slate-400">
            <span className="flex items-center gap-1"><Wallet className="h-3.5 w-3.5" /> Virtual funds</span>
            <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" /> Learning plan</span>
            <span className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5" /> Risk guardrails</span>
          </div>
        </div>
      </section>
    </main>
  );
};
