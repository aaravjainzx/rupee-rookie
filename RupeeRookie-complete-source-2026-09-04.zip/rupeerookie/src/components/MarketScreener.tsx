import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  TrendingUp, 
  TrendingDown, 
  ArrowUpDown, 
  Heart,
  Sparkles, 
  Activity,
  ArrowRight,
  Zap,
  Globe,
  Flame,
  LayoutGrid,
  TableProperties,
  Compass,
  Layers,
  CheckCircle2,
  ShoppingBag,
  ListFilter,
  BarChart3,
  Building2,
  Cpu,
  Landmark,
  Car,
  Pill,
  ShieldCheck,
  Tag,
  Bell,
  SlidersHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  PieChart,
  X,
  ChevronRight,
  Rocket,
  HelpCircle
} from 'lucide-react';
import { useSimulator } from '../context/SimulatorContext';
import { StockDetail } from '../types';
import { formatINR, formatPercent, formatIndianShort, formatNumberIndian } from '../utils/formatters';
import { ThematicBasketsModal, ANGEL_THEMATIC_BASKETS, ThematicBasket } from './ThematicBasketsModal';
import { QuickAlertModal } from './QuickAlertModal';

const getBenchmarkGradient = (id: string) => {
  switch (id) {
    case 'NIFTY_50':
      return 'bg-gradient-to-br from-amber-500 via-orange-500 to-emerald-600 text-white shadow-amber-500/25 border-amber-300/40';
    case 'SENSEX_30':
      return 'bg-gradient-to-br from-blue-600 to-indigo-800 text-white shadow-blue-500/25 border-blue-400/30';
    case 'NIFTY_IT':
      return 'bg-gradient-to-br from-cyan-600 to-indigo-600 text-white shadow-cyan-500/25 border-cyan-400/30';
    case 'NIFTY_BANK':
      return 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-emerald-500/25 border-emerald-400/30';
    case 'NIFTY_AUTO':
      return 'bg-gradient-to-br from-amber-500 to-red-600 text-white shadow-orange-500/25 border-amber-400/30';
    case 'NIFTY_PHARMA':
      return 'bg-gradient-to-br from-rose-500 to-pink-600 text-white shadow-rose-500/25 border-rose-400/30';
    case 'NIFTY_DEFENCE_PSU':
      return 'bg-gradient-to-br from-slate-800 via-indigo-950 to-slate-900 text-amber-300 shadow-slate-900/30 border-amber-400/30';
    case 'NIFTY_CONSUMER':
      return 'bg-gradient-to-br from-fuchsia-600 to-purple-700 text-white shadow-fuchsia-500/25 border-fuchsia-400/30';
    case 'NIFTY_GREEN_ENERGY':
      return 'bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-green-500/25 border-green-400/30';
    case 'NIFTY_METALS':
      return 'bg-gradient-to-br from-yellow-600 to-amber-700 text-white shadow-yellow-500/25 border-yellow-400/30';
    default:
      return 'bg-gradient-to-br from-indigo-600 to-violet-700 text-white shadow-indigo-500/25 border-indigo-400/30';
  }
};

interface MarketScreenerProps {
  onSelectStock: (stock: StockDetail) => void;
  onOpenApiModal?: () => void;
}

// Benchmark Index Definitions & Subheadings
export interface BenchmarkIndexInfo {
  id: string;
  name: string;
  shortName: string;
  icon: string;
  tagline: string;
  description: string;
  symbols: string[];
}

export const BENCHMARK_INDEX_SUBHEADINGS: BenchmarkIndexInfo[] = [
  {
    id: 'NIFTY_50',
    name: 'NIFTY 50',
    shortName: 'NIFTY 50',
    icon: '🇮🇳',
    tagline: "India's Flagship 50 Bluechips",
    description: "The premier benchmark representing the 50 largest and most liquid Indian companies across key economic sectors.",
    symbols: [
      'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'ITC', 'BHARTIARTL', 'SBIN', 'LT', 'HINDUNILVR',
      'TATAMOTORS', 'M&M', 'SUNPHARMA', 'TITAN', 'AXISBANK', 'KOTAKBANK', 'BAJFINANCE', 'MARUTI', 'NTPC',
      'ONGC', 'POWERGRID', 'TATASTEEL', 'COALINDIA', 'JSWSTEEL', 'ADANIENT', 'ADANIPORTS', 'HCLTECH', 'WIPRO',
      'TECHM', 'ULTRACEMCO', 'GRASIM', 'NESTLEIND', 'ASIANPAINT', 'DRREDDY', 'CIPLA', 'APOLLOHOSP', 'HEROMOTOCO',
      'EICHERMOT', 'BAJAJ-AUTO', 'TRENT', 'BEL', 'HAL', 'SBILIFE', 'HDFCLIFE', 'BAJAJFINSV', 'SHRIRAMFIN',
      'BPCL', 'TATACONSUM', 'DIVISLAB', 'INDUSINDBK', 'BRITANNIA'
    ]
  },
  {
    id: 'SENSEX_30',
    name: 'BSE SENSEX 30',
    shortName: 'SENSEX 30',
    icon: '🏛️',
    tagline: 'Dalal Street 30 Bellwether',
    description: "The historic 30-stock index of the Bombay Stock Exchange (BSE), tracking India's most established corporate giants.",
    symbols: [
      'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'ITC', 'BHARTIARTL', 'SBIN', 'LT', 'HINDUNILVR',
      'TATAMOTORS', 'M&M', 'SUNPHARMA', 'TITAN', 'AXISBANK', 'KOTAKBANK', 'BAJFINANCE', 'MARUTI', 'NTPC',
      'POWERGRID', 'TATASTEEL', 'JSWSTEEL', 'HCLTECH', 'TECHM', 'ULTRACEMCO', 'NESTLEIND', 'ASIANPAINT',
      'BAJAJFINSV', 'TRENT', 'INDUSINDBK'
    ]
  },
  {
    id: 'NIFTY_IT',
    name: 'NIFTY IT',
    shortName: 'NIFTY IT',
    icon: '💻',
    tagline: 'Technology & Enterprise AI',
    description: "Global consulting powerhouses, enterprise AI innovators, cloud architects, and software services exporters.",
    symbols: [
      'TCS', 'INFY', 'HCLTECH', 'WIPRO', 'TECHM', 'LTIM', 'PERSISTENT', 'COFORGE', 'MPHASIS', 'LTTS', 'TATAELXSI', 'KPITTECH', 'OFSS', 'CYIENT'
    ]
  },
  {
    id: 'NIFTY_BANK',
    name: 'NIFTY BANK & FINANCIALS',
    shortName: 'NIFTY BANK',
    icon: '🏦',
    tagline: 'Financial & Banking Titans',
    description: "India's highest capitalized commercial banks, NBFC leaders, insurance giants, and digital payment infrastructure.",
    symbols: [
      'HDFCBANK', 'ICICIBANK', 'SBIN', 'AXISBANK', 'KOTAKBANK', 'INDUSINDBK', 'BANKBARODA', 'PNB', 'FEDERALBNK',
      'IDFCFIRSTB', 'AUBANK', 'BAJFINANCE', 'BAJAJFINSV', 'MUTHOOTFIN', 'CHOLAFIN', 'LICI', 'SBICARD', 'HDFCAMC'
    ]
  },
  {
    id: 'NIFTY_AUTO',
    name: 'NIFTY AUTO & EV',
    shortName: 'NIFTY AUTO',
    icon: '🚗',
    tagline: 'Automotive & EV Revolution',
    description: "Automobile OEMs, electric mobility innovators, two-wheeler champions, commercial vehicles, and auto components.",
    symbols: [
      'TATAMOTORS', 'M&M', 'MARUTI', 'BAJAJ-AUTO', 'EICHERMOT', 'HEROMOTOCO', 'TVSMOTOR', 'BHARATFORG',
      'BOSCHLTD', 'MOTHERSON', 'TIINDIA', 'ASHOKLEY', 'OLAELEC', 'OLECTRA', 'AMARAJABAT', 'EXIDEIND'
    ]
  },
  {
    id: 'NIFTY_PHARMA',
    name: 'NIFTY PHARMA & HEALTHCARE',
    shortName: 'NIFTY PHARMA',
    icon: '💊',
    tagline: 'Healthcare & Life Sciences',
    description: "Generic medicine producers, super-specialty hospital chains, diagnostic networks, and biotechnology innovators.",
    symbols: [
      'SUNPHARMA', 'CIPLA', 'DRREDDY', 'DIVISLAB', 'APOLLOHOSP', 'MANKIND', 'ZYDUSLIFE', 'TORNTPHARM',
      'LUPIN', 'AUROPHARMA', 'BIOCON', 'MAXHEALTH', 'FORTIS'
    ]
  },
  {
    id: 'NIFTY_DEFENCE_PSU',
    name: 'NIFTY DEFENCE, PSU & RAILWAYS',
    shortName: 'DEFENCE & PSU',
    icon: '🛡️',
    tagline: 'Maharatnas & Sovereign Infrastructure',
    description: "Strategic Maharatnas, Vande Bharat train manufacturers, missile & fighter jet builders, and public utility leaders.",
    symbols: [
      'HAL', 'BEL', 'RVNL', 'IRFC', 'IRCTC', 'MAZDOCK', 'COCHINSHIP', 'BDL', 'BEML', 'BHEL', 'NTPC',
      'ONGC', 'POWERGRID', 'COALINDIA', 'SAIL', 'IOC', 'BPCL', 'GAIL', 'PFC', 'RECLTD', 'IREDA', 'NHPC', 'SJVN', 'RAILTEL', 'CONCOR'
    ]
  },
  {
    id: 'NIFTY_CONSUMER',
    name: 'NIFTY CONSUMER & QUICK COMMERCE',
    shortName: 'CONSUMER & RETAIL',
    icon: '🛍️',
    tagline: 'FMCG, Food & Retail Brands',
    description: "Household FMCG staples, 10-minute grocery apps, pizza chains, trendsetting apparel, and youth lifestyle brands.",
    symbols: [
      'ITC', 'HINDUNILVR', 'NESTLEIND', 'BRITANNIA', 'TATACONSUM', 'DABUR', 'MARICO', 'GODREJCP',
      'COLPAL', 'VARUN', 'VBL', 'JUBLFOOD', 'DEVYANI', 'ZOMATO', 'SWIGGY', 'TRENT', 'TITAN', 'NYKAA',
      'CAMPUS', 'HONASA', 'BATAINDIA', 'PAGEIND', 'PVRINOX'
    ]
  }
];

// Rich Synonym & Keyword Dictionary for Natural Language Stock Finding
export const CLIENT_KEYWORD_MAP: Record<string, string[]> = {
  "maggi": ["NESTLEIND"],
  "maggie": ["NESTLEIND"],
  "noodles": ["NESTLEIND"],
  "kitkat": ["NESTLEIND"],
  "coffee": ["NESTLEIND", "DEVYANI", "TATACONSUM"],
  "nescafe": ["NESTLEIND"],
  "chocolate": ["NESTLEIND"],
  "bullet": ["EICHERMOT"],
  "classic 350": ["EICHERMOT"],
  "royal enfield": ["EICHERMOT"],
  "hunter": ["EICHERMOT"],
  "himalayan": ["EICHERMOT"],
  "thar": ["M&M"],
  "scorpio": ["M&M"],
  "xuv": ["M&M"],
  "bolero": ["M&M"],
  "tractor": ["M&M"],
  "nexon": ["TATAMOTORS"],
  "harrier": ["TATAMOTORS"],
  "safari": ["TATAMOTORS"],
  "punch": ["TATAMOTORS"],
  "curvv": ["TATAMOTORS"],
  "jio": ["RELIANCE"],
  "petrol": ["RELIANCE", "IOC", "BPCL", "ONGC"],
  "diesel": ["RELIANCE", "IOC", "BPCL", "ONGC"],
  "oil": ["ONGC", "OIL", "RELIANCE", "IOC", "BPCL"],
  "refinery": ["RELIANCE", "IOC", "BPCL"],
  "ambani": ["RELIANCE"],
  "airtel": ["BHARTIARTL"],
  "5g": ["BHARTIARTL", "RELIANCE"],
  "sim": ["BHARTIARTL", "RELIANCE"],
  "broadband": ["BHARTIARTL", "RELIANCE"],
  "blinkit": ["ZOMATO"],
  "zomato": ["ZOMATO"],
  "food delivery": ["ZOMATO", "SWIGGY", "JUBLFOOD", "DEVYANI"],
  "swiggy": ["SWIGGY"],
  "instamart": ["SWIGGY"],
  "zudio": ["TRENT"],
  "westside": ["TRENT"],
  "star bazaar": ["TRENT"],
  "apparel": ["TRENT", "PAGEIND", "VEDANT", "BATAINDIA"],
  "fashion": ["TRENT", "NYKAA", "PAGEIND", "TITAN"],
  "dominos": ["JUBLFOOD"],
  "domino's": ["JUBLFOOD"],
  "pizza": ["JUBLFOOD", "DEVYANI"],
  "kfc": ["DEVYANI"],
  "pizza hut": ["DEVYANI"],
  "costa coffee": ["DEVYANI"],
  "train": ["RVNL", "IRFC", "IRCTC", "RAILTEL", "CONCOR"],
  "trains": ["RVNL", "IRFC", "IRCTC", "RAILTEL", "CONCOR"],
  "railway": ["RVNL", "IRFC", "IRCTC", "RAILTEL", "CONCOR"],
  "railways": ["RVNL", "IRFC", "IRCTC", "RAILTEL", "CONCOR"],
  "vande bharat": ["RVNL", "IRFC", "IRCTC"],
  "ticket": ["IRCTC"],
  "food in train": ["IRCTC"],
  "tejas": ["HAL"],
  "fighter jet": ["HAL"],
  "defence": ["HAL", "BEL", "MAZDOCK", "BDL", "COCHINSHIP", "SOLARINDS"],
  "defense": ["HAL", "BEL", "MAZDOCK", "BDL", "COCHINSHIP", "SOLARINDS"],
  "helicopter": ["HAL"],
  "missile": ["BDL", "BEL"],
  "warship": ["MAZDOCK", "COCHINSHIP"],
  "submarine": ["MAZDOCK"],
  "radar": ["BEL"],
  "ev": ["TATAMOTORS", "M&M", "OLAELEC", "OLECTRA", "AMARAJABAT", "EXIDEIND"],
  "electric vehicle": ["TATAMOTORS", "M&M", "OLAELEC", "OLECTRA"],
  "battery": ["EXIDEIND", "AMARAJABAT"],
  "solar": ["IREDA", "TATAPOWER", "WAAREE", "SUZLON", "PREMIERENE"],
  "green energy": ["IREDA", "TATAPOWER", "SUZLON", "ADANIGREEN", "NHPC", "SJVN"],
  "wind": ["SUZLON", "TATAPOWER"],
  "hospital": ["APOLLOHOSP", "MAXHEALTH", "FORTIS"],
  "medicine": ["SUNPHARMA", "CIPLA", "DRREDDY", "DIVISLAB", "MANKIND", "ZYDUSLIFE"],
  "pharma": ["SUNPHARMA", "CIPLA", "DRREDDY", "DIVISLAB", "MANKIND", "ZYDUSLIFE"],
  "aeroplane": ["INDIGO"],
  "flight": ["INDIGO"],
  "airlines": ["INDIGO"],
  "gold": ["TITAN", "MUTHOOTFIN", "MANAPPURAM"],
  "jewellery": ["TITAN", "KALYANKJIL"],
  "tanishq": ["TITAN"],
  "watches": ["TITAN"],
  "fastrack": ["TITAN"],
  "cinema": ["PVRINOX"],
  "movie": ["PVRINOX"],
  "movies": ["PVRINOX"],
  "theatre": ["PVRINOX"],
  "popcorn": ["PVRINOX"],
  "steel": ["TATASTEEL", "JSWSTEEL", "SAIL", "JINDALSTEL"],
  "cement": ["ULTRACEMCO", "AMBUJACEM", "ACC", "SHREECEM", "DALBHARAT"],
  "bank": ["HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK", "KOTAKBANK", "BANKBARODA", "PNB", "FEDERALBNK", "IDFCFIRSTB"],
  "banking": ["HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK", "KOTAKBANK", "BANKBARODA", "PNB", "FEDERALBNK", "IDFCFIRSTB"],
  "loan": ["BAJFINANCE", "HDFCBANK", "SBIN", "ICICIBANK", "AXISBANK", "PFC", "RECLTD"],
  "credit card": ["SBICARD", "HDFCBANK", "ICICIBANK", "AXISBANK"],
  "insurance": ["LICI", "SBILIFE", "HDFCLIFE", "ICICIPRULI"],
  "lic": ["LICI"],
  "it": ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "TATAELXSI", "PERSISTENT", "COFORGE"],
  "software": ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "TATAELXSI", "PERSISTENT", "COFORGE"],
  "tech": ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "TATAELXSI", "PERSISTENT", "COFORGE"],
  "ai": ["TATAELXSI", "PERSISTENT", "COFORGE", "TCS", "INFY", "KPITTECH"],
  "nifty": ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "ITC", "BHARTIARTL", "SBIN", "LT", "HINDUNILVR", "TATAMOTORS", "M&M"],
  "nifty 50": ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "ITC", "BHARTIARTL", "SBIN", "LT", "HINDUNILVR", "TATAMOTORS", "M&M"],
  "nifty 30": ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "ITC", "BHARTIARTL", "SBIN", "LT", "HINDUNILVR", "TATAMOTORS", "M&M"],
  "sensex": ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "ITC", "BHARTIARTL", "SBIN", "LT", "HINDUNILVR", "TATAMOTORS", "M&M"],
  "sensex 30": ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "ITC", "BHARTIARTL", "SBIN", "LT", "HINDUNILVR", "TATAMOTORS", "M&M"],
  "nifty it": ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "TATAELXSI", "PERSISTENT", "COFORGE"],
  "nifty bank": ["HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK", "KOTAKBANK", "BANKBARODA", "PNB", "FEDERALBNK"],
  "nifty auto": ["TATAMOTORS", "M&M", "MARUTI", "BAJAJ-AUTO", "EICHERMOT", "HEROMOTOCO", "TVSMOTOR"],
  "nifty pharma": ["SUNPHARMA", "CIPLA", "DRREDDY", "DIVISLAB", "APOLLOHOSP", "MANKIND", "ZYDUSLIFE"],
  "psu": ["SBIN", "HAL", "BEL", "RVNL", "IRFC", "IRCTC", "NTPC", "ONGC", "POWERGRID", "COALINDIA", "SAIL", "IOC", "BPCL", "GAIL", "PFC", "RECLTD", "IREDA"]
};

// Popular Teen Search Chips for Instant Filtering
const POPULAR_BRAND_CHIPS = [
  { name: 'Maggi', query: 'Maggi' },
  { name: 'Zudio', query: 'Zudio' },
  { name: 'Nifty IT', query: 'Nifty IT' },
  { name: 'Sensex 30', query: 'Sensex' },
  { name: 'Bullet 350', query: 'Bullet' },
  { name: 'Blinkit', query: 'Blinkit' },
  { name: 'Vande Bharat', query: 'Vande Bharat' },
  { name: 'Tejas Jet', query: 'Tejas' },
  { name: 'Jio 5G', query: 'Jio' },
  { name: 'Nifty Auto', query: 'Nifty Auto' },
  { name: 'Nifty Bank', query: 'Nifty Bank' },
  { name: 'Domino\'s', query: 'Domino\'s' },
];

export const MarketScreener: React.FC<MarketScreenerProps> = ({ onSelectStock, onOpenApiModal }) => {
  const { stocks, watchlist, toggleWatchlist, marketIndices, marketNews, executeBuyOrder, cashBalance, nseMarketInfo, isMarketLive, lastHoldingsSyncTime } = useSimulator();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBenchmark, setSelectedBenchmark] = useState<string>('ALL'); // 'ALL' or benchmark ID
  const [groupBySubheadings, setGroupBySubheadings] = useState<boolean>(true);
  const [selectedSector, setSelectedSector] = useState('ALL');
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'GAINERS' | 'LOSERS' | '52W_HIGH' | '52W_LOW' | 'WATCHLIST'>('ALL');
  const [strategyPreset, setStrategyPreset] = useState<'ALL' | 'GOLDEN_CROSS' | 'HIGH_DIVIDEND' | 'HIGH_ROE' | 'RSI_DIP' | 'PSU_GIANTS' | 'MOMENTUM'>('ALL');
  const [sortBy, setSortBy] = useState<'POPULAR' | 'PRICE_HIGH' | 'PRICE_LOW' | 'GAIN_HIGH' | 'LOSS_HIGH' | 'PE_LOW' | 'MCAP_HIGH'>('POPULAR');
  const [viewMode, setViewMode] = useState<'CARDS' | 'TABLE'>('CARDS');
  const [visibleCount, setVisibleCount] = useState(9);
  const [activeMarketSection, setActiveMarketSection] = useState<'EQUITIES' | 'BASKETS' | 'HEATMAP' | 'MOVERS'>('EQUITIES');

  // Angel One Modal & Interactive State
  const [selectedThematicBasket, setSelectedThematicBasket] = useState<ThematicBasket | null>(null);
  const [isBasketModalOpen, setIsBasketModalOpen] = useState(false);
  const [quickAlertStock, setQuickAlertStock] = useState<StockDetail | null>(null);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  const [activeIndexTab, setActiveIndexTab] = useState<'NIFTY50' | 'SENSEX' | 'BANKNIFTY' | 'NIFTYIT' | 'NIFTYAUTO' | 'NIFTYPHARMA' | 'DEFENCE'>('NIFTY50');

  const [liveSearchResults, setLiveSearchResults] = useState<{symbol: string, name: string}[]>([]);
  const [isSearchingLive, setIsSearchingLive] = useState(false);
  const [marketPulse, setMarketPulse] = useState<string>("Bulls leading Dalal Street with strong retail momentum in tech, EV, and quick commerce.");
  const [basketOrderMessage, setBasketOrderMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [advancedFiltersOpen, setAdvancedFiltersOpen] = useState(false);

  // Live search backend hook
  useEffect(() => {
    if (searchQuery.length > 2) {
      setIsSearchingLive(true);
      const timer = setTimeout(async () => {
        try {
          const res = await fetch(`/api/stocks/search?q=${encodeURIComponent(searchQuery)}`);
          const data = await res.json();
          if (data.success && data.results) {
            const existingSymbols = new Set(stocks.map(s => s.symbol));
            setLiveSearchResults(data.results.filter((r: any) => !existingSymbols.has(r.symbol)));
          }
        } catch (err) {
          console.error(err);
        } finally {
          setIsSearchingLive(false);
        }
      }, 400);
      return () => clearTimeout(timer);
    } else {
      setLiveSearchResults([]);
      setIsSearchingLive(false);
    }
  }, [searchQuery, stocks]);

  useEffect(() => {
    fetch('/api/market-pulse')
      .then(r => r.json())
      .then(d => {
        if (d.success) setMarketPulse(d.pulse);
      })
      .catch(() => setMarketPulse("Dalal Street trading with high liquidity & teen participation today!"));
  }, []);

  const handleTrackLiveStock = async (symbol: string) => {
    try {
      const res = await fetch('/api/stocks/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol })
      });
      const data = await res.json();
      if (data.success && data.stock) {
        onSelectStock(data.stock);
        setSearchQuery('');
        setLiveSearchResults([]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Helper to determine which benchmark indices a stock belongs to
  const getStockIndices = useMemo(() => {
    return (symbol: string): string[] => {
      const matched: string[] = [];
      BENCHMARK_INDEX_SUBHEADINGS.forEach(b => {
        if (b.symbols.includes(symbol)) {
          matched.push(b.shortName);
        }
      });
      return matched;
    };
  }, []);

  // Sectors list
  const sectors = useMemo(() => {
    const set = new Set<string>();
    stocks.forEach((s) => set.add(s.sector));
    return ['ALL', ...Array.from(set)];
  }, [stocks]);

  // Market Highlights
  const topGainer = useMemo(() => {
    if (stocks.length === 0) return null;
    return [...stocks].sort((a, b) => b.changePercent - a.changePercent)[0];
  }, [stocks]);

  const topLoser = useMemo(() => {
    if (stocks.length === 0) return null;
    return [...stocks].sort((a, b) => a.changePercent - b.changePercent)[0];
  }, [stocks]);

  const mostActive = useMemo(() => {
    if (stocks.length === 0) return null;
    return [...stocks].sort((a, b) => b.volume - a.volume)[0];
  }, [stocks]);

  const near52WHighStock = useMemo(() => {
    if (stocks.length === 0) return null;
    return [...stocks].sort((a, b) => {
      const aDiff = Math.abs(a.price - (a.high52 || a.price));
      const bDiff = Math.abs(b.price - (b.high52 || b.price));
      return aDiff - bDiff;
    })[0];
  }, [stocks]);

  // Market Breadth (Advances vs Declines)
  const marketBreadth = useMemo(() => {
    let advances = 0;
    let declines = 0;
    let neutral = 0;
    stocks.forEach((s) => {
      if (s.changePercent > 0.05) advances++;
      else if (s.changePercent < -0.05) declines++;
      else neutral++;
    });
    const total = advances + declines + neutral || 1;
    return {
      advances,
      declines,
      neutral,
      advancePct: Math.round((advances / total) * 100),
      declinePct: Math.round((declines / total) * 100)
    };
  }, [stocks]);

  // Live Sector Heatmap & Money Flow Stats
  const sectorHeatmapStats = useMemo(() => {
    const map: Record<string, { totalGain: number; count: number; bestStock: StockDetail }> = {};
    stocks.forEach((s) => {
      if (!map[s.sector]) {
        map[s.sector] = { totalGain: 0, count: 0, bestStock: s };
      }
      map[s.sector].totalGain += s.changePercent;
      map[s.sector].count += 1;
      if (s.changePercent > map[s.sector].bestStock.changePercent) {
        map[s.sector].bestStock = s;
      }
    });
    return Object.entries(map).map(([sec, data]) => ({
      sector: sec,
      avgChange: data.totalGain / (data.count || 1),
      count: data.count,
      bestStock: data.bestStock
    })).sort((a, b) => b.avgChange - a.avgChange);
  }, [stocks]);

  // Matching reason lookup for search results
  const getStockMatchReason = useMemo(() => {
    return (stock: StockDetail, query: string): string | null => {
      const q = query.toLowerCase().trim();
      if (!q) return null;
      if (stock.symbol.toLowerCase() === q) return `Exact Symbol Match`;
      if (stock.name.toLowerCase().includes(q)) return `Matched Company Name`;
      if (stock.popularBrands?.some(b => b.toLowerCase().includes(q))) {
        const found = stock.popularBrands.find(b => b.toLowerCase().includes(q));
        return `Brand: ${found}`;
      }
      for (const [key, symbols] of Object.entries(CLIENT_KEYWORD_MAP)) {
        if ((q.includes(key) || key.includes(q)) && symbols.includes(stock.symbol)) {
          return `Keyword: "${key}"`;
        }
      }
      return null;
    };
  }, []);

  // Filtered and Sorted Stocks List
  const filteredStocks = useMemo(() => {
    return stocks.filter((stock) => {
      // 1. Natural Language & Keyword Search Match
      const q = searchQuery.toLowerCase().trim();
      if (q) {
        const matchesSymbol = stock.symbol.toLowerCase().includes(q);
        const matchesName = stock.name.toLowerCase().includes(q);
        const matchesSector = stock.sector.toLowerCase().includes(q);
        const matchesBrands = stock.popularBrands?.some(b => b.toLowerCase().includes(q));
        const matchesTeenSummary = stock.teenSummary?.toLowerCase().includes(q);
        const matchesDescription = stock.description?.toLowerCase().includes(q);

        // Check if query matches keyword map
        let matchesKeywordMap = false;
        for (const [key, symbols] of Object.entries(CLIENT_KEYWORD_MAP)) {
          if ((q.includes(key) || key.includes(q)) && symbols.includes(stock.symbol)) {
            matchesKeywordMap = true;
            break;
          }
        }

        if (!matchesSymbol && !matchesName && !matchesSector && !matchesBrands && !matchesTeenSummary && !matchesDescription && !matchesKeywordMap) {
          return false;
        }
      }

      // 2. Selected Benchmark Index Filter
      if (selectedBenchmark !== 'ALL') {
        const benchmarkDef = BENCHMARK_INDEX_SUBHEADINGS.find(b => b.id === selectedBenchmark);
        if (benchmarkDef && !benchmarkDef.symbols.includes(stock.symbol)) {
          return false;
        }
      }

      // 3. Sector filter
      if (selectedSector !== 'ALL' && stock.sector !== selectedSector) return false;

      // 4. Highlight Filter Tabs
      if (selectedFilter === 'GAINERS' && stock.changePercent <= 0) return false;
      if (selectedFilter === 'LOSERS' && stock.changePercent >= 0) return false;
      if (selectedFilter === '52W_HIGH' && (stock.price / stock.high52) < 0.90) return false;
      if (selectedFilter === '52W_LOW' && ((stock.price - stock.low52) / (stock.low52 || 1)) > 0.25) return false;
      if (selectedFilter === 'WATCHLIST' && !watchlist.includes(stock.symbol)) return false;

      // 5. Strategy Screener Presets
      if (strategyPreset === 'GOLDEN_CROSS') {
        const ema50 = stock.ema50 || stock.price * 1.01;
        const ema200 = stock.ema200 || stock.price * 0.97;
        if (ema50 < ema200) return false;
      }
      if (strategyPreset === 'HIGH_DIVIDEND') {
        if (stock.dividendYield < 2.0 || stock.peRatio > 26) return false;
      }
      if (strategyPreset === 'HIGH_ROE') {
        if ((stock.roe || 12) < 16) return false;
      }
      if (strategyPreset === 'RSI_DIP') {
        const rsi = stock.rsi14 || 50;
        if (rsi > 46 && stock.changePercent > -1.0) return false;
      }
      if (strategyPreset === 'PSU_GIANTS') {
        const psuSymbols = ['SBIN', 'HAL', 'BEL', 'RVNL', 'IRFC', 'IRCTC', 'NTPC', 'ONGC', 'POWERGRID', 'COALINDIA', 'SAIL', 'IOC', 'BPCL', 'GAIL', 'PFC', 'RECLTD', 'IREDA', 'BANKBARODA', 'PNB', 'NHPC', 'SJVN'];
        if (!psuSymbols.includes(stock.symbol)) return false;
      }
      if (strategyPreset === 'MOMENTUM') {
        if (stock.price < (stock.high52 * 0.93)) return false;
      }

      return true;
    }).sort((a, b) => {
      // If searching, prioritize stocks that directly match keyword
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const aExact = a.symbol.toLowerCase() === q ? 2 : (a.popularBrands?.some(br => br.toLowerCase().includes(q)) ? 1 : 0);
        const bExact = b.symbol.toLowerCase() === q ? 2 : (b.popularBrands?.some(br => br.toLowerCase().includes(q)) ? 1 : 0);
        if (aExact !== bExact) return bExact - aExact;
      }

      if (sortBy === 'PRICE_HIGH') return b.price - a.price;
      if (sortBy === 'PRICE_LOW') return a.price - b.price;
      if (sortBy === 'GAIN_HIGH') return b.changePercent - a.changePercent;
      if (sortBy === 'LOSS_HIGH') return a.changePercent - b.changePercent;
      if (sortBy === 'PE_LOW') return a.peRatio - b.peRatio;
      if (sortBy === 'MCAP_HIGH') return b.marketCapCr - a.marketCapCr;
      return 0;
    });
  }, [stocks, searchQuery, selectedBenchmark, selectedSector, selectedFilter, strategyPreset, sortBy, watchlist]);

  useEffect(() => {
    setVisibleCount(9);
  }, [searchQuery, selectedBenchmark, selectedSector, selectedFilter, strategyPreset, sortBy, viewMode]);

  const displayedStocks = useMemo(() => filteredStocks.slice(0, visibleCount), [filteredStocks, visibleCount]);

  // Grouped Stocks under each Benchmark Subheading
  const benchmarkGroupedSections = useMemo(() => {
    if (selectedBenchmark !== 'ALL') {
      const b = BENCHMARK_INDEX_SUBHEADINGS.find(item => item.id === selectedBenchmark);
      if (!b) return [];
      const groupStocks = displayedStocks.filter(s => b.symbols.includes(s.symbol));
      return groupStocks.length > 0 ? [{ benchmark: b, stocks: groupStocks }] : [];
    }

    const sections: Array<{ benchmark: BenchmarkIndexInfo; stocks: StockDetail[] }> = [];
    const renderedSymbols = new Set<string>();
    BENCHMARK_INDEX_SUBHEADINGS.forEach((b) => {
      const groupStocks = displayedStocks.filter(s => b.symbols.includes(s.symbol) && !renderedSymbols.has(s.symbol));
      if (groupStocks.length > 0) {
        groupStocks.forEach((stock) => renderedSymbols.add(stock.symbol));
        sections.push({
          benchmark: b,
          stocks: groupStocks
        });
      }
    });

    // Also include other listed equities not in the predefined benchmark baskets
    const unassignedStocks = displayedStocks.filter(s => !renderedSymbols.has(s.symbol));
    if (unassignedStocks.length > 0) {
      sections.push({
        benchmark: {
          id: 'OTHER_EQUITIES',
          name: 'OTHER DALAL STREET EQUITIES',
          shortName: 'MID & SMALLCAP',
          icon: '✨',
          tagline: 'High Growth Emerging Leaders',
          description: 'Specialized mid-cap and emerging market leaders with strong retail interest.',
          symbols: []
        },
        stocks: unassignedStocks
      });
    }

    return sections;
  }, [displayedStocks, selectedBenchmark]);

  return (
    <div className="space-y-6 min-w-0 max-w-full overflow-hidden">
      <div className={`flex flex-col gap-2 rounded-2xl border p-3 text-xs sm:flex-row sm:items-center sm:justify-between ${isMarketLive ? 'border-emerald-200 bg-emerald-50 text-emerald-950' : 'border-amber-200 bg-amber-50 text-amber-950'}`} role="status">
        <div className="flex items-center gap-2"><span className={`rounded-full px-2 py-1 text-[9px] font-black ${isMarketLive ? 'bg-emerald-600 text-white' : 'bg-amber-500 text-slate-950'}`}>{isMarketLive ? 'LATEST' : nseMarketInfo.isNSEMarketOpen ? 'DELAYED' : 'LAST CLOSE'}</span><span className="font-bold">{isMarketLive ? 'Latest available provider quote; exchange data may be delayed.' : nseMarketInfo.isNSEMarketOpen ? 'The feed may be delayed. Confirm important figures with an exchange-authorised source.' : 'Market is closed. Figures show the last available session; live-style language is disabled.'}</span></div><span className="shrink-0 font-mono text-[10px]">Updated {lastHoldingsSyncTime} IST · RupeeRookie market feed</span>
      </div>
      {/* 2. DEDICATED VIEW SECTIONS (SHOWN BASED ON ACTIVE TAB) */}

      {/* A. THEMATIC BASKETS SECTION */}
      {activeMarketSection === 'BASKETS' && (
        <div className="bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center text-xl shadow-sm font-black shrink-0">
                🎯
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-white">Curated Thematic Baskets</h4>
                  <span className="bg-amber-400/20 text-amber-300 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase border border-amber-400/30">
                    Smart Portfolios
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-medium">Research-backed thematic portfolios with instant 1-click allocation</p>
              </div>
            </div>

            <button
              onClick={() => setActiveMarketSection('EQUITIES')}
              className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition-all flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <span>Back to All Equities</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
            {ANGEL_THEMATIC_BASKETS.map((b) => (
              <div
                key={b.id}
                onClick={() => {
                  setSelectedThematicBasket(b);
                  setIsBasketModalOpen(true);
                }}
                className="bg-white/10 hover:bg-white/15 backdrop-blur-xs border border-white/10 hover:border-amber-400/60 rounded-2xl p-5 transition-all cursor-pointer flex flex-col justify-between group shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{b.icon}</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-xs font-black px-2.5 py-0.5 rounded-full border border-emerald-400/30 font-mono">
                      {b.cagr3Y}
                    </span>
                  </div>
                  <h5 className="font-black text-sm text-white mt-3 group-hover:text-amber-300 transition-colors">
                    {b.title}
                  </h5>
                  <p className="text-xs text-slate-300 mt-1 font-medium leading-relaxed">
                    {b.subtitle}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-2 font-normal line-clamp-2">
                    {b.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                  <span className="text-xs text-slate-300 font-mono font-bold">{b.symbols.length} Equities Included</span>
                  <span className="text-amber-300 font-black flex items-center gap-1 text-xs group-hover:translate-x-1 transition-transform">
                    <span>1-Click Invest</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* B. SECTOR HEATMAP SECTION */}
      {activeMarketSection === 'HEATMAP' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Activity className="w-5 h-5 text-indigo-600" />
              <div>
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  Sector Heatmap & Institutional Money Flow
                </h4>
                <p className="text-xs text-slate-500 font-medium">Click any sector card to filter the full screener list</p>
              </div>
            </div>
            <button
              onClick={() => {
                setSelectedSector('ALL');
                setActiveMarketSection('EQUITIES');
              }}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              Reset Filters
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {sectorHeatmapStats.map((stat) => {
              const isSelected = selectedSector === stat.sector;
              const isPositive = stat.avgChange >= 0;
              return (
                <button
                  key={stat.sector}
                  onClick={() => {
                    setSelectedSector(isSelected ? 'ALL' : stat.sector);
                    setActiveMarketSection('EQUITIES');
                  }}
                  className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : isPositive
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950 hover:bg-emerald-100 hover:border-emerald-300'
                        : 'bg-rose-50/70 border-rose-200 text-rose-950 hover:bg-rose-100 hover:border-rose-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider truncate block">{stat.sector}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/70 border border-slate-200 text-slate-700">
                      {stat.count} stocks
                    </span>
                  </div>
                  <span className={`font-mono text-base font-black ${
                    isSelected ? 'text-amber-300' : isPositive ? 'text-emerald-700' : 'text-rose-700'
                  }`}>
                    {isPositive ? '+' : ''}{stat.avgChange.toFixed(2)}%
                  </span>
                  <div className="pt-2 border-t border-black/5 flex items-center justify-between text-[10px]">
                    <span className={isSelected ? 'text-slate-300' : 'text-slate-500'}>Top Leader:</span>
                    <span className={`font-bold ${isSelected ? 'text-white' : 'text-slate-900'}`}>{stat.bestStock.symbol} (+{stat.bestStock.changePercent}%)</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* C. MARKET MOVERS SECTION */}
      {activeMarketSection === 'MOVERS' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Activity className="w-5 h-5 text-emerald-600" />
              <div>
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  {isMarketLive ? 'Live Market Movers & Drivers' : 'Last-session Movers & Drivers'}
                </h4>
                <p className="text-xs text-slate-500 font-medium">Top gainers, value dips, high volume breakouts and 52W extremes</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Top Gainer */}
            {topGainer && (
              <div 
                onClick={() => onSelectStock(topGainer)}
                className="bg-emerald-50/60 hover:bg-emerald-50 border border-emerald-200 hover:border-emerald-400 rounded-2xl p-4 shadow-2xs cursor-pointer transition-all hover:shadow-xs flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs text-emerald-800 font-black">
                      <TrendingUp className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" /> 
                      <span>TOP GAINER</span>
                    </span>
                    <span className="text-[10px] font-black text-emerald-700 bg-emerald-100/90 px-2 py-0.5 rounded-full border border-emerald-300">
                      +{topGainer.changePercent}%
                    </span>
                  </div>
                  <div className="font-black text-base text-slate-900 mt-2">{topGainer.name}</div>
                  <div className="text-xs text-slate-500">{topGainer.sector} • ₹{topGainer.price.toFixed(2)}</div>
                </div>
                <div className="mt-4 pt-3 border-t border-emerald-200/60 flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-medium">High: ₹{topGainer.high52}</span>
                  <span className="text-emerald-700 font-bold flex items-center gap-0.5">Trade <ChevronRight className="w-3 h-3" /></span>
                </div>
              </div>
            )}

            {/* Top Value Dip */}
            {topLoser && (
              <div 
                onClick={() => onSelectStock(topLoser)}
                className="bg-rose-50/60 hover:bg-rose-50 border border-rose-200 hover:border-rose-400 rounded-2xl p-4 shadow-2xs cursor-pointer transition-all hover:shadow-xs flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs text-rose-800 font-black">
                      <TrendingDown className="w-4 h-4 text-rose-600 group-hover:scale-110 transition-transform" /> 
                      <span>VALUE DIP</span>
                    </span>
                    <span className="text-[10px] font-black text-rose-700 bg-rose-100/90 px-2 py-0.5 rounded-full border border-rose-300">
                      {topLoser.changePercent}%
                    </span>
                  </div>
                  <div className="font-black text-base text-slate-900 mt-2">{topLoser.name}</div>
                  <div className="text-xs text-slate-500">P/E: {topLoser.peRatio} • ₹{topLoser.price.toFixed(2)}</div>
                </div>
                <div className="mt-4 pt-3 border-t border-rose-200/60 flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-medium">Low: ₹{topLoser.low52}</span>
                  <span className="text-rose-700 font-bold flex items-center gap-0.5">Trade <ChevronRight className="w-3 h-3" /></span>
                </div>
              </div>
            )}

            {/* Most Active Volume */}
            {mostActive && (
              <div 
                onClick={() => onSelectStock(mostActive)}
                className="bg-slate-50 hover:bg-white border border-slate-200 hover:border-slate-400 rounded-2xl p-4 shadow-2xs cursor-pointer transition-all hover:shadow-xs flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs text-indigo-700 font-black">
                      <Zap className="w-4 h-4 text-indigo-600 group-hover:scale-110 transition-transform" /> 
                      <span>VOLUME SURGE</span>
                    </span>
                    <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                      {mostActive.changePercent >= 0 ? '+' : ''}{mostActive.changePercent}%
                    </span>
                  </div>
                  <div className="font-black text-base text-slate-900 mt-2">{mostActive.name}</div>
                  <div className="text-xs text-slate-500">{formatNumberIndian(mostActive.volume)} shares traded</div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                  <span className="text-slate-600 font-medium">{mostActive.sector}</span>
                  <span className="text-indigo-700 font-bold flex items-center gap-0.5">Trade <ChevronRight className="w-3 h-3" /></span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. UNIFIED FILTER & SCREENER COMMAND CENTER */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-6 shadow-sm space-y-4 min-w-0 max-w-full overflow-hidden">
        {/* Main Search & Control Bar */}
        <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1 min-w-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search stocks by brand, symbol, or sector"
              placeholder="Search stocks by Brand, Symbol, Sector (Maggi, Bullet, Zudio, Nifty IT)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-16 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-900 focus:bg-white transition-colors placeholder:text-slate-400"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-900 font-bold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Clean Controls: Sector Dropdown, Index Dropdown, Sort Dropdown, View Switcher */}
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 min-w-0">
            {/* Sector Dropdown */}
            <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 min-w-0">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Sector:</span>
              <select
                aria-label="Filter by sector"
                value={selectedSector}
                onChange={(e) => setSelectedSector(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-900 focus:outline-none cursor-pointer py-1 min-w-0 w-full sm:max-w-[110px]"
              >
                {sectors.map(sec => (
                  <option key={sec} value={sec}>{sec === 'ALL' ? 'All Sectors' : sec}</option>
                ))}
              </select>
            </div>

            {/* Benchmark Index Dropdown */}
            <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 min-w-0">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Index:</span>
              <select
                aria-label="Filter by market index"
                value={selectedBenchmark}
                onChange={(e) => setSelectedBenchmark(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-900 focus:outline-none cursor-pointer py-1 min-w-0 w-full sm:max-w-[120px]"
              >
                <option value="ALL">All Indices</option>
                {BENCHMARK_INDEX_SUBHEADINGS.map(b => (
                  <option key={b.id} value={b.id}>{b.shortName}</option>
                ))}
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="hidden items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 min-w-0">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
              <select
                aria-label="Sort stocks"
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-900 focus:outline-none cursor-pointer py-1 min-w-0 w-full"
              >
                <option value="POPULAR">Most Popular</option>
                <option value="PRICE_HIGH">Price: High to Low</option>
                <option value="PRICE_LOW">Price: Low to High</option>
                <option value="GAIN_HIGH">Top Gainers (%)</option>
                <option value="LOSS_HIGH">Top Losers (%)</option>
                <option value="PE_LOW">Lowest P/E</option>
                <option value="MCAP_HIGH">Market Cap</option>
              </select>
            </div>

            {/* Benchmark Subheading Grouping Toggle */}
            <label className="hidden items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-bold text-slate-800 cursor-pointer hover:bg-slate-100 transition-colors">
              <input
                type="checkbox"
                checked={groupBySubheadings}
                onChange={(e) => setGroupBySubheadings(e.target.checked)}
                className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-600 cursor-pointer"
              />
              <span className="hidden sm:inline">Group</span>
            </label>

            {/* View Mode Toggle */}
            <div className="hidden items-center bg-slate-50 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode('CARDS')}
                className={`p-1.5 rounded-lg transition-all ${viewMode === 'CARDS' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
                title="Visual Cards View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('TABLE')}
                className={`p-1.5 rounded-lg transition-all ${viewMode === 'TABLE' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
                title="Pro Terminal Table View"
              >
                <TableProperties className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => setAdvancedFiltersOpen(true)}
              className="col-span-2 flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-black text-slate-800 hover:border-indigo-400 sm:col-span-1"
            >
              <SlidersHorizontal className="h-4 w-4 text-indigo-600" /> Advanced screeners
              {strategyPreset !== 'ALL' && <span className="h-2 w-2 rounded-full bg-amber-500" />}
            </button>
          </div>
        </div>

        {/* Quick Filter Tabs Row */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 scrollbar-none text-xs pt-1">
          <button
            onClick={() => setSelectedFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 ${
              selectedFilter === 'ALL'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-white'
            }`}
          >
            All Stocks ({filteredStocks.length})
          </button>

          <button
            onClick={() => setSelectedFilter('GAINERS')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 flex items-center gap-1.5 ${
              selectedFilter === 'GAINERS'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Top Gainers
          </button>

          <button
            onClick={() => setSelectedFilter('LOSERS')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 flex items-center gap-1.5 ${
              selectedFilter === 'LOSERS'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" /> Value Dips
          </button>

          <button
            onClick={() => setSelectedFilter('52W_HIGH')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 flex items-center gap-1.5 ${
              selectedFilter === '52W_HIGH'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Near 52W High
          </button>

          <button
            onClick={() => setSelectedFilter('52W_LOW')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 ${
              selectedFilter === '52W_LOW'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            52W Discount 🏷️
          </button>

          <button
            onClick={() => setSelectedFilter('WATCHLIST')}
            className={`px-3 py-1.5 rounded-xl font-black transition-all shrink-0 flex items-center gap-1.5 ${
              selectedFilter === 'WATCHLIST'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <Heart className="w-3.5 h-3.5 fill-rose-600 text-rose-600" /> Favorites ({watchlist.length})
          </button>
        </div>

        <AnimatePresence>
          {advancedFiltersOpen && (
            <div className="fixed inset-0 z-[95] flex justify-end bg-slate-950/55 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Advanced market screeners">
              <button type="button" className="flex-1 cursor-default" onClick={() => setAdvancedFiltersOpen(false)} aria-label="Close advanced screeners" />
              <motion.aside initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }} transition={{ duration: 0.2 }} className="h-full w-full max-w-md overflow-y-auto bg-white p-5 shadow-2xl sm:p-6">
                <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
                  <div><p className="text-[10px] font-black uppercase tracking-[0.14em] text-indigo-600">Optional tools</p><h3 className="text-xl font-black text-slate-900">Advanced screeners</h3><p className="mt-1 text-xs text-slate-500">Refine the list only when you need deeper screening.</p></div>
                  <button type="button" onClick={() => setAdvancedFiltersOpen(false)} className="rounded-xl border border-slate-200 p-2 text-slate-600" aria-label="Close advanced screeners"><X className="h-4 w-4" /></button>
                </div>

                <div className="mt-5 space-y-5">
                  <label className="block"><span className="text-xs font-black text-slate-700">Sort results</span><select value={sortBy} onChange={(event) => setSortBy(event.target.value as typeof sortBy)} className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs font-bold text-slate-900 outline-none"><option value="POPULAR">Most popular</option><option value="PRICE_HIGH">Price: high to low</option><option value="PRICE_LOW">Price: low to high</option><option value="GAIN_HIGH">Top gainers</option><option value="LOSS_HIGH">Top decliners</option><option value="PE_LOW">Lowest P/E</option><option value="MCAP_HIGH">Market cap</option></select></label>

                  <div><span className="text-xs font-black text-slate-700">Display</span><div className="mt-2 grid grid-cols-2 gap-2"><button type="button" onClick={() => setViewMode('CARDS')} className={`rounded-xl border px-3 py-2.5 text-xs font-black ${viewMode === 'CARDS' ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-600'}`}><LayoutGrid className="mr-1.5 inline h-4 w-4" />Cards</button><button type="button" onClick={() => setViewMode('TABLE')} className={`rounded-xl border px-3 py-2.5 text-xs font-black ${viewMode === 'TABLE' ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-600'}`}><TableProperties className="mr-1.5 inline h-4 w-4" />Table</button></div><label className="mt-2 flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-xs font-bold text-slate-700"><input type="checkbox" checked={groupBySubheadings} onChange={(event) => setGroupBySubheadings(event.target.checked)} /> Group companies by index</label></div>

                  <div><span className="text-xs font-black text-slate-700">Strategy presets</span><div className="mt-2 grid grid-cols-2 gap-2">{([
                    ['GOLDEN_CROSS', 'Golden crossover'], ['HIGH_DIVIDEND', 'Dividend value'], ['HIGH_ROE', 'High ROE quality'], ['RSI_DIP', 'RSI pullback'], ['PSU_GIANTS', 'Maharatna PSUs'], ['MOMENTUM', 'Momentum breakout']
                  ] as const).map(([value, label]) => <button key={value} type="button" onClick={() => setStrategyPreset(strategyPreset === value ? 'ALL' : value)} className={`rounded-xl border px-3 py-2.5 text-left text-xs font-black ${strategyPreset === value ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-200 bg-white text-slate-700'}`}>{label}</button>)}</div></div>

                  <button type="button" onClick={() => { setSortBy('POPULAR'); setGroupBySubheadings(true); setViewMode('CARDS'); setStrategyPreset('ALL'); }} className="w-full rounded-xl border border-slate-300 py-2.5 text-xs font-black text-slate-700">Reset advanced options</button>
                  <button type="button" onClick={() => setAdvancedFiltersOpen(false)} className="w-full rounded-xl bg-slate-900 py-3 text-xs font-black text-white">Show results</button>
                </div>
              </motion.aside>
            </div>
          )}
        </AnimatePresence>

        {/* Pre-Built Strategy Screeners Row */}
        <div className="hidden items-center gap-1.5 overflow-x-auto max-w-full pb-1 scrollbar-none text-xs pt-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider shrink-0 flex items-center gap-1">
            <SlidersHorizontal className="w-3 h-3 text-indigo-600" /> Screeners:
          </span>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'GOLDEN_CROSS' ? 'ALL' : 'GOLDEN_CROSS')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'GOLDEN_CROSS'
                ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="50 EMA crossing above 200 EMA bullish signal"
          >
            <span>⚡ Golden Crossover</span>
          </button>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'HIGH_DIVIDEND' ? 'ALL' : 'HIGH_DIVIDEND')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'HIGH_DIVIDEND'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="Dividend Yield > 2% with attractive P/E"
          >
            <span>💰 High Dividend & Value</span>
          </button>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'HIGH_ROE' ? 'ALL' : 'HIGH_ROE')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'HIGH_ROE'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="High ROE > 16% Quality Compounding"
          >
            <span>🚀 High ROE Quality</span>
          </button>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'RSI_DIP' ? 'ALL' : 'RSI_DIP')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'RSI_DIP'
                ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="RSI < 45 Oversold pullback setup"
          >
            <span>🎯 RSI Dip Rebound</span>
          </button>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'PSU_GIANTS' ? 'ALL' : 'PSU_GIANTS')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'PSU_GIANTS'
                ? 'bg-purple-600 text-white border-purple-600 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="Maharatna & Navratna PSU Giants"
          >
            <span>🏛️ Maharatna PSUs</span>
          </button>
          <button
            onClick={() => setStrategyPreset(strategyPreset === 'MOMENTUM' ? 'ALL' : 'MOMENTUM')}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black border transition-all shrink-0 flex items-center gap-1 ${
              strategyPreset === 'MOMENTUM'
                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="Trading within 7% of 52-week all-time highs"
          >
            <span>🔥 Momentum Breakout</span>
          </button>
          {strategyPreset !== 'ALL' && (
            <button
              onClick={() => setStrategyPreset('ALL')}
              className="text-[10px] font-bold text-rose-600 hover:underline px-1 shrink-0"
            >
              Reset Screener
            </button>
          )}
        </div>

        {/* Quick Brand Search Suggestions */}
        <div className="hidden items-center gap-1.5 overflow-x-auto max-w-full pb-1 scrollbar-none text-xs border-t border-slate-100 pt-2.5">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Tag className="w-3 h-3 text-slate-500" /> Suggestions:
          </span>
          {POPULAR_BRAND_CHIPS.map((chip) => (
            <button
              key={chip.name}
              onClick={() => setSearchQuery(chip.query)}
              className={`px-2 py-0.5 rounded-md border transition-all shrink-0 font-bold text-[10px] cursor-pointer ${
                searchQuery.toLowerCase() === chip.query.toLowerCase()
                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                  : 'bg-slate-50 text-slate-500 border-slate-200 hover:border-slate-400 hover:text-slate-800'
              }`}
            >
              {chip.name}
            </button>
          ))}
        </div>

        {/* 1-Click Thematic Index Basket Investment Bar (when benchmark selected) */}
        {selectedBenchmark !== 'ALL' && (
          <div className="mt-3 pt-3 border-t border-slate-200 bg-indigo-50/70 -mx-5 -mb-5 sm:-mx-6 sm:-mb-6 p-4 sm:p-5 rounded-b-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-dashed border-indigo-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base">{BENCHMARK_INDEX_SUBHEADINGS.find(b => b.id === selectedBenchmark)?.icon}</span>
                <span className="text-xs font-black text-indigo-950">
                  1-Click Invest in {BENCHMARK_INDEX_SUBHEADINGS.find(b => b.id === selectedBenchmark)?.name} Basket ({filteredStocks.length} Stocks)
                </span>
                <span className="bg-indigo-200 text-indigo-900 text-[9px] font-black px-2 py-0.5 rounded-full">
                  BENCHMARK BASKET
                </span>
              </div>
              <p className="text-[11px] text-indigo-900/80 mt-0.5 font-medium">
                {BENCHMARK_INDEX_SUBHEADINGS.find(b => b.id === selectedBenchmark)?.description}
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[10px] text-indigo-900 font-bold uppercase hidden md:inline">Allocate:</span>
              {[10000, 25000, 50000].map((amt) => (
                <button
                  key={amt}
                  onClick={() => {
                    if (filteredStocks.length === 0) return;
                    if (amt > cashBalance) {
                      setBasketOrderMessage({
                        text: `Insufficient virtual cash. Required: ${formatINR(amt)}, Available: ${formatINR(cashBalance)}`,
                        isError: true
                      });
                      return;
                    }
                    const perStockAmt = amt / filteredStocks.length;
                    let count = 0;
                    filteredStocks.forEach(s => {
                      const qty = Math.max(1, Math.floor(perStockAmt / (s.price || 1)));
                      if (qty > 0) {
                        executeBuyOrder(s.symbol, qty, 'MARKET');
                        count++;
                      }
                    });
                    const bName = BENCHMARK_INDEX_SUBHEADINGS.find(b => b.id === selectedBenchmark)?.name;
                    setBasketOrderMessage({
                      text: `🎉 Successfully invested ${formatINR(amt)} across ${count} stocks in the "${bName}" basket!`,
                      isError: false
                    });
                    setTimeout(() => setBasketOrderMessage(null), 5000);
                  }}
                  className="flex-1 sm:flex-none px-3 py-1.5 rounded-xl bg-indigo-900 hover:bg-indigo-950 text-white text-xs font-black shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                >
                  <ShoppingBag className="w-3 h-3 text-amber-400" />
                  <span>{formatIndianShort(amt)}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Basket Order Feedback Banner */}
      {basketOrderMessage && (
        <div className={`p-4 rounded-2xl text-xs font-bold border flex items-center gap-2.5 shadow-sm ${
          basketOrderMessage.isError
            ? 'bg-rose-50 border-rose-200 text-rose-800'
            : 'bg-emerald-50 border-emerald-200 text-emerald-900'
        }`}>
          {basketOrderMessage.isError ? (
            <span className="text-rose-600">❌</span>
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          )}
          <span>{basketOrderMessage.text}</span>
        </div>
      )}

      {/* Live Search Results from Network */}
      {searchQuery.length > 2 && (liveSearchResults.length > 0 || isSearchingLive) && (
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-5 h-5 text-slate-900 animate-pulse" />
            <h3 className="text-sm font-extrabold text-slate-900">NSE Market Discovery</h3>
          </div>
          {isSearchingLive ? (
            <div className="text-xs text-slate-500 font-bold px-2">Scanning National Stock Exchange with verified quote sync...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {liveSearchResults.map(res => (
                <div key={res.symbol} className="bg-white rounded-xl p-3 flex justify-between items-center shadow-sm border border-slate-200 hover:border-slate-200 transition-colors">
                  <div className="overflow-hidden">
                    <div className="font-bold text-slate-900 text-sm truncate">{res.symbol}</div>
                    <div className="text-[10px] text-slate-500 truncate">{res.name}</div>
                  </div>
                  <button onClick={() => handleTrackLiveStock(res.symbol)} className="shrink-0 ml-2 bg-slate-900 hover:bg-slate-800 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold shadow-sm transition-all">
                    Load & Trade
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 1: VISUAL STOCK CARDS (EITHER GROUPED BY SUBHEADINGS OR FLAT) */}
      {viewMode === 'CARDS' && filteredStocks.length > 0 && (
        <div className="space-y-8">
          {groupBySubheadings ? (
            /* GROUPED BY BENCHMARK INDEX SUBHEADINGS */
            benchmarkGroupedSections.map(({ benchmark, stocks: groupStocks }) => (
              <div key={benchmark.id} className="space-y-4">
                
                {/* SUBHEADING HEADER BANNER */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${getBenchmarkGradient(benchmark.id)} text-xl flex items-center justify-center shadow-md border shrink-0`}>
                      {benchmark.icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-base font-black text-slate-900">{benchmark.name}</h2>
                        <span className="text-[10px] font-black bg-[#E2E8F0] text-slate-900 px-2 py-0.5 rounded-md">
                          {benchmark.tagline}
                        </span>
                        <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md">
                          {groupStocks.length} Constituents
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium mt-0.5">{benchmark.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (selectedBenchmark === benchmark.id) {
                        setSelectedBenchmark('ALL');
                      } else {
                        setSelectedBenchmark(benchmark.id);
                      }
                    }}
                    className="shrink-0 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white text-xs font-bold text-slate-900 transition-colors"
                  >
                    {selectedBenchmark === benchmark.id ? 'Show All Indices' : 'Focus This Index'}
                  </button>
                </div>

                {/* Grid of Stocks under this Subheading */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {groupStocks.map((stock) => (
                    <StockCardItem
                      key={stock.symbol}
                      stock={stock}
                      onSelectStock={onSelectStock}
                      watchlist={watchlist}
                      toggleWatchlist={toggleWatchlist}
                      searchQuery={searchQuery}
                      matchReason={getStockMatchReason(stock, searchQuery)}
                      indices={getStockIndices(stock.symbol)}
                      onOpenAlert={(s) => {
                        setQuickAlertStock(s);
                        setIsAlertModalOpen(true);
                      }}
                      onQuickBuy={(s) => {
                        executeBuyOrder(s.symbol, 1, 'MARKET');
                      }}
                    />
                  ))}
                </div>
              </div>
            ))
          ) : (
            /* FLAT GRID OF ALL FILTERED STOCKS */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {displayedStocks.map((stock) => (
                <StockCardItem
                  key={stock.symbol}
                  stock={stock}
                  onSelectStock={onSelectStock}
                  watchlist={watchlist}
                  toggleWatchlist={toggleWatchlist}
                  searchQuery={searchQuery}
                  matchReason={getStockMatchReason(stock, searchQuery)}
                  indices={getStockIndices(stock.symbol)}
                  onOpenAlert={(s) => {
                    setQuickAlertStock(s);
                    setIsAlertModalOpen(true);
                  }}
                  onQuickBuy={(s) => {
                    executeBuyOrder(s.symbol, 1, 'MARKET');
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: PRO TERMINAL TABLE VIEW */}
      {viewMode === 'TABLE' && filteredStocks.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-black uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-4">Symbol / Company</th>
                  <th className="p-4">Benchmark Subheading</th>
                  <th className="p-4 text-right">Price (₹)</th>
                  <th className="p-4 text-right">24h Change</th>
                  <th className="p-4 text-right">P/E Ratio</th>
                  <th className="p-4 text-right">Market Cap</th>
                  <th className="p-4">Famous Brands</th>
                  <th className="p-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {displayedStocks.map((stock) => {
                  const isUp = stock.change >= 0;
                  const indices = getStockIndices(stock.symbol);
                  return (
                    <tr
                      key={stock.symbol}
                      onClick={() => onSelectStock(stock)}
                      className="hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      <td className="p-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-black text-slate-900 text-sm">{stock.symbol}</span>
                          {stock.psuStatus && (
                            <span className="text-[9px] font-black bg-blue-100 text-blue-900 border border-blue-200 px-1 py-0.2 rounded">
                              {stock.psuStatus}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[200px]">{stock.name}</div>
                      </td>
                      <td className="p-4">
                        <div className="flex flex-wrap gap-1 max-w-[180px]">
                          {indices.map(idx => (
                            <span key={idx} className="bg-indigo-50 text-indigo-900 border border-indigo-200 text-[9px] px-1.5 py-0.2 rounded font-bold">
                              {idx}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="p-4 text-right font-black font-mono text-sm text-slate-900">
                        {formatINR(stock.price)}
                      </td>
                      <td className="p-4 text-right">
                        <span className={`inline-block font-black px-2 py-0.5 rounded-md text-[11px] ${
                          isUp ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isUp ? '+' : ''}{stock.changePercent.toFixed(2)}%
                        </span>
                      </td>
                      <td className="p-4 text-right font-mono font-bold text-slate-900">
                        {stock.peRatio}x
                      </td>
                      <td className="p-4 text-right font-bold text-slate-500">
                        {formatIndianShort(stock.marketCapCr * 10000000)}
                      </td>
                      <td className="p-4">
                        <div className="flex flex-wrap gap-1 max-w-[200px]">
                          {stock.popularBrands?.slice(0, 2).map((b, idx) => (
                            <span key={idx} className="bg-amber-50 text-amber-900 border border-amber-200 text-[10px] px-2 py-0.2 rounded-md font-semibold">
                              {b}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-1.5" onClick={e => e.stopPropagation()}>
                          <button
                            onClick={() => {
                              setQuickAlertStock(stock);
                              setIsAlertModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg border border-slate-200 hover:bg-amber-100 text-slate-500 hover:text-amber-800"
                            title="Set Price Trigger Alert"
                          >
                            <Bell className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onSelectStock(stock)}
                            className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 shadow-xs"
                          >
                            Trade
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {filteredStocks.length > 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-xs">
          <p className="text-xs font-semibold text-slate-600">
            Showing {Math.min(displayedStocks.length, filteredStocks.length)} of {filteredStocks.length} matching companies
          </p>
          {displayedStocks.length < filteredStocks.length && (
            <button
              type="button"
              onClick={() => setVisibleCount((count) => count + 9)}
              className="w-full sm:w-auto rounded-xl bg-slate-900 px-4 py-2 text-xs font-black text-white hover:bg-slate-800"
            >
              Load 9 more
            </button>
          )}
        </div>
      )}

      {/* Empty Filter State */}
      {filteredStocks.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-slate-500 shadow-sm">
          {selectedFilter === 'WATCHLIST' ? (
            <>
              <div className="w-16 h-16 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-rose-200">
                <Heart className="w-8 h-8 text-rose-600 fill-rose-600" />
              </div>
              <p className="text-lg font-bold text-slate-900">Your Favorites List is Empty</p>
              <p className="text-sm text-slate-500 mt-2 max-w-md mx-auto">
                Pin your favorite stocks from the catalog by clicking the heart icon to curate a focused watchlist.
              </p>
              <button
                onClick={() => setSelectedFilter('ALL')}
                className="mt-6 px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-extrabold shadow-md transition-all cursor-pointer"
              >
                Explore Market Catalog
              </button>
            </>
          ) : (
            <>
              <p className="text-base font-bold text-slate-900">No stocks match "{searchQuery || 'your criteria'}"</p>
              <p className="text-xs text-slate-500 mt-1">Try searching for keywords like "Maggi", "Bullet", "Zudio", "Nifty IT", "Sensex", or clear your filter.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedBenchmark('ALL');
                  setSelectedSector('ALL');
                  setSelectedFilter('ALL');
                }}
                className="mt-4 px-5 py-2.5 rounded-xl bg-slate-900 text-xs font-extrabold text-white shadow-md hover:bg-slate-800 cursor-pointer"
              >
                Reset All Filters
              </button>
            </>
          )}
        </div>
      )}

      {/* ANGEL ONE THEMATIC BASKETS MODAL */}
      <ThematicBasketsModal
        isOpen={isBasketModalOpen}
        onClose={() => setIsBasketModalOpen(false)}
        selectedBasket={selectedThematicBasket}
        onSelectBasket={(basket) => setSelectedThematicBasket(basket)}
        onSelectStock={(stock) => {
          setIsBasketModalOpen(false);
          onSelectStock(stock);
        }}
      />

      {/* ANGEL ONE PRICE ALERT MODAL */}
      <QuickAlertModal
        isOpen={isAlertModalOpen}
        onClose={() => {
          setIsAlertModalOpen(false);
          setQuickAlertStock(null);
        }}
        stock={quickAlertStock}
      />

    </div>
  );
};

// Reusable Individual Stock Card Component with Angel One Quick Actions & Price Alerts
interface StockCardItemProps {
  stock: StockDetail;
  onSelectStock: (stock: StockDetail) => void;
  watchlist: string[];
  toggleWatchlist: (symbol: string) => void;
  searchQuery: string;
  matchReason: string | null;
  indices: string[];
  onOpenAlert: (stock: StockDetail) => void;
  onQuickBuy: (stock: StockDetail) => void;
}

const StockCardItem: React.FC<StockCardItemProps> = ({
  stock,
  onSelectStock,
  watchlist,
  toggleWatchlist,
  matchReason,
  indices,
  onOpenAlert,
  onQuickBuy
}) => {
  const isUp = stock.change >= 0;
  const isWatchlisted = watchlist.includes(stock.symbol);
  const rangeSpan = stock.high52 - stock.low52;
  const currentPosPercent = Math.min(100, Math.max(0, ((stock.price - stock.low52) / (rangeSpan || 1)) * 100));
  const isLowPe = stock.peRatio < stock.industryPe;
  const isNear52Low = currentPosPercent <= 25;
  const isBreakout = stock.changePercent >= 2.0;
  const quoteTimeLabel = stock.quoteAsOf
    ? new Date(stock.quoteAsOf).toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className="bg-gradient-to-b from-white via-white to-slate-50/80 border border-slate-200/90 hover:border-slate-400 rounded-3xl p-6 shadow-xs flex flex-col justify-between transition-all hover:shadow-lg group cursor-pointer"
      onClick={() => onSelectStock(stock)}
    >
      {/* Header with Symbol, Name, Star */}
      <div>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-center font-black text-slate-900 text-sm shadow-2xs group-hover:scale-105 transition-transform">
              {stock.symbol.substring(0, 3)}
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="font-black text-slate-900 text-base group-hover:text-indigo-950 transition-colors">
                  {stock.symbol}
                </h3>
                <span className="text-[10px] text-slate-700 bg-slate-100 font-bold px-1.5 py-0.5 rounded-md border border-slate-200/80">
                  NSE
                </span>
                {stock.psuStatus && (
                  <span className="text-[9px] font-black bg-blue-100 text-blue-900 border border-blue-200 px-1.5 py-0.5 rounded-md">
                    🏛️ {stock.psuStatus}
                  </span>
                )}
                {isBreakout && (
                  <span className="text-[9px] font-black bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-md">
                    🔥 Breakout
                  </span>
                )}
                {isNear52Low && (
                  <span className="text-[9px] font-black bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-md">
                    🏷️ Sale
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium line-clamp-1">{stock.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => onOpenAlert(stock)}
              className="p-2 rounded-full border bg-white border-slate-200 text-slate-500 hover:text-amber-600 hover:border-amber-300 transition-all shadow-2xs cursor-pointer"
              title="Set Price Alert Trigger"
            >
              <Bell className="w-4 h-4" />
            </button>
            <button
              onClick={() => toggleWatchlist(stock.symbol)}
              className={`transition-all p-2 rounded-full border shadow-2xs cursor-pointer ${isWatchlisted ? 'bg-rose-50 border-rose-200 text-rose-600 hover:bg-rose-100' : 'bg-white border-slate-200 text-slate-500 hover:text-rose-600'}`}
              title={isWatchlisted ? 'Remove from Favorites' : 'Add to Favorites'}
            >
              <Heart className={`w-4 h-4 ${isWatchlisted ? 'fill-rose-600 text-rose-600' : ''}`} />
            </button>
          </div>
        </div>

        {/* Index Badges & Keyword Match Indicator */}
        <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
          {indices.map(idx => (
            <span key={idx} className="bg-slate-100/90 text-slate-800 border border-slate-200 text-[9px] px-2 py-0.2 rounded-md font-bold">
              {idx}
            </span>
          ))}
          {matchReason && (
            <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[9px] px-2 py-0.2 rounded-md font-black flex items-center gap-0.5">
              <span>🎯</span>
              <span>{matchReason}</span>
            </span>
          )}
        </div>

        {/* Price & Today's Change */}
        <div className="mt-3.5 flex items-baseline justify-between">
          <div>
            <span className="text-2xl font-black text-slate-900 tracking-tight font-mono">
              {formatINR(stock.price)}
            </span>
          </div>
          <div className={`flex items-center text-xs font-black px-2.5 py-1 rounded-xl shadow-2xs ${
            isUp ? 'bg-emerald-100/90 text-emerald-800 border border-emerald-200' : 'bg-rose-100/90 text-rose-800 border border-rose-200'
          }`}>
            {isUp ? '+' : ''}{stock.change.toFixed(2)} ({formatPercent(stock.changePercent)})
          </div>
        </div>
        {quoteTimeLabel && (
          <p className="mt-1.5 text-[9px] font-bold text-slate-500" title={`Market quote source: ${stock.quoteSource || 'NSE quote provider'}`}>
            Latest available · {quoteTimeLabel} IST · {stock.quoteSource || 'NSE quote provider'}
          </p>
        )}

        {/* 52-Week Range Slider Bar */}
          <div className="mt-3 bg-slate-50/90 p-2.5 rounded-2xl border border-slate-200/90" title="The position between the lowest and highest traded prices recorded over the previous 52 weeks. It is context, not a buy or sell signal.">
          <div className="flex justify-between text-[10px] text-slate-500 font-bold mb-1">
            <span>52W L: ₹{stock.low52.toFixed(0)}</span>
            <span className="text-slate-900 font-black">{currentPosPercent.toFixed(0)}% of 52W High</span>
            <span>52W H: ₹{stock.high52.toFixed(0)}</span>
          </div>
          <div className="relative h-2 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-rose-400 via-amber-400 to-emerald-500 rounded-full"
              style={{ width: `${currentPosPercent}%` }}
            />
          </div>
        </div>

        {/* Valuation & Fundamentals Row */}
        <div className="grid grid-cols-2 gap-2 mt-3 text-[11px]">
          <div className="bg-slate-50/90 p-2.5 rounded-xl border border-slate-200/90">
            <span className="text-slate-500 font-semibold flex items-center gap-1 text-[10px] uppercase"><abbr className="no-underline" title="Price-to-earnings ratio: market price divided by earnings per share. Compare it with business quality, growth and peers—not by itself.">P/E Ratio</abbr><HelpCircle className="h-3 w-3" aria-hidden="true" /></span>
            <div className="flex items-center justify-between mt-0.5">
              <span className="font-extrabold text-slate-900">{stock.peRatio}</span>
              <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-md ${
                isLowPe ? 'text-emerald-700 bg-emerald-100' : 'text-slate-500 bg-slate-200'
              }`}>
                Ind: {stock.industryPe}
              </span>
            </div>
          </div>

          <div className="bg-slate-50/90 p-2.5 rounded-xl border border-slate-200/90">
            <span className="text-slate-500 font-semibold flex items-center gap-1 text-[10px] uppercase"><abbr className="no-underline" title="Market capitalisation: share price multiplied by shares outstanding. It describes company size, not how cheap it is.">Market Cap</abbr><HelpCircle className="h-3 w-3" aria-hidden="true" /></span>
            <span className="font-extrabold text-slate-900 block mt-0.5">{formatIndianShort(stock.marketCapCr * 10000000)}</span>
          </div>
        </div>

        {/* Famous Brands Tags for Teens */}
        {stock.popularBrands && stock.popularBrands.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {stock.popularBrands.slice(0, 3).map((brand, bIdx) => (
              <span key={bIdx} className="bg-amber-50/90 text-amber-900 border border-amber-200 text-[10px] px-2.5 py-0.5 rounded-lg font-bold">
                {brand}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Action Buttons */}
      <div className="mt-4 pt-3.5 border-t border-slate-200/80 flex items-center justify-between gap-2">
        <span className="text-[11px] text-slate-500 font-bold uppercase tracking-wide truncate max-w-[100px]">
          {stock.sector}
        </span>
        
        <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
          <button
            onClick={() => onQuickBuy(stock)}
            className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-xs transition-all flex items-center gap-1 cursor-pointer"
            title="Instant 1-Click Buy 1 Share"
          >
            <Zap className="w-3 h-3 text-amber-300" />
            <span>Buy 1</span>
          </button>
          
          <button
            id={`trade-btn-${stock.symbol}`}
            onClick={() => onSelectStock(stock)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs shadow-xs transition-all group-hover:scale-102 cursor-pointer"
          >
            <span>Trade</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </motion.div>
  );
};

// Helper for top highlights brand fallback
function stockHasBrand(s: StockDetail): string | undefined {
  return s.popularBrands && s.popularBrands.length > 0 ? s.popularBrands[0] : undefined;
}
