import React, { useEffect, useMemo, useRef, useState } from 'react';
import { BarChart3, BookOpen, Calculator, Command, Home, PieChart, Search, ShieldCheck, Sparkles, X } from 'lucide-react';
import type { StockDetail } from '../types';
import type { AppTabType } from './Header';

interface CommandPaletteProps {
  stocks: StockDetail[];
  onNavigate: (tab: AppTabType) => void;
  onSelectStock: (stock: StockDetail) => void;
}

const destinations: Array<{ tab: AppTabType; label: string; description: string; icon: React.ElementType }> = [
  { tab: 'home', label: 'Home', description: 'Today, learning progress and portfolio summary', icon: Home },
  { tab: 'screener', label: 'Markets', description: 'Search and compare Indian companies', icon: BarChart3 },
  { tab: 'portfolio', label: 'Portfolio', description: 'Positions, risk and watchlist', icon: PieChart },
  { tab: 'academy', label: 'Academy', description: 'Lessons, case studies and portfolio models', icon: BookOpen },
  { tab: 'journal', label: 'Trade journal', description: 'Plans, screenshots and reflections', icon: Sparkles },
  { tab: 'calculator', label: 'Calculator', description: 'Compare investment scenarios', icon: Calculator },
  { tab: 'privacy', label: 'Data & privacy', description: 'Exports, storage and data controls', icon: ShieldCheck },
];

export function CommandPalette({ stocks, onNavigate, onSelectStock }: CommandPaletteProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.isContentEditable;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setOpen((value) => !value);
      } else if (event.key === '/' && !typing) {
        event.preventDefault();
        setOpen(true);
      } else if (event.key === 'Escape') {
        setOpen(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    window.setTimeout(() => inputRef.current?.focus(), 30);
  }, [open]);

  const filteredDestinations = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return destinations;
    return destinations.filter((item) => `${item.label} ${item.description}`.toLowerCase().includes(needle));
  }, [query]);

  const filteredStocks = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    return stocks.filter((stock) => `${stock.symbol} ${stock.name} ${stock.sector || ''}`.toLowerCase().includes(needle)).slice(0, 6);
  }, [query, stocks]);

  const close = () => setOpen(false);

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="fixed bottom-24 right-4 z-50 flex min-h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-700 shadow-lg dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 lg:bottom-6 lg:right-40" aria-label="Open app search">
        <Search className="h-4 w-4" /><span className="hidden sm:inline">Search app</span><kbd className="hidden rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] dark:bg-slate-800 lg:inline">Ctrl K</kbd>
      </button>
      {open && (
        <div className="fixed inset-0 z-[110] flex items-start justify-center px-3 pt-[8vh] sm:pt-[12vh]" role="dialog" aria-modal="true" aria-label="Search RupeeRookie">
          <button type="button" className="absolute inset-0 bg-slate-950/65 backdrop-blur-sm" onClick={close} aria-label="Close app search" />
          <div className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="flex items-center gap-3 border-b border-slate-200 p-4 dark:border-slate-700">
              <Search className="h-5 w-5 text-indigo-600" />
              <input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pages, stocks or learning tools…" className="min-w-0 flex-1 bg-transparent text-base font-bold outline-none placeholder:font-medium placeholder:text-slate-400" aria-label="Search pages and stocks" />
              <button type="button" onClick={close} className="rounded-xl p-2 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close"><X className="h-5 w-5" /></button>
            </div>
            <div className="max-h-[65vh] overflow-y-auto p-3">
              {filteredDestinations.length > 0 && <p className="px-2 pb-2 text-[10px] font-black uppercase tracking-widest text-slate-400">Go to</p>}
              {filteredDestinations.map((item) => {
                const Icon = item.icon;
                return <button key={item.tab} type="button" onClick={() => { onNavigate(item.tab); close(); }} className="flex w-full items-center gap-3 rounded-2xl p-3 text-left hover:bg-indigo-50 focus:bg-indigo-50 focus:outline-none dark:hover:bg-indigo-950/40 dark:focus:bg-indigo-950/40"><span className="rounded-xl bg-slate-100 p-2 dark:bg-slate-800"><Icon className="h-4 w-4" /></span><span><span className="block text-sm font-black">{item.label}</span><span className="block text-xs text-slate-500 dark:text-slate-400">{item.description}</span></span></button>;
              })}
              {filteredStocks.length > 0 && <p className="px-2 pb-2 pt-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Companies</p>}
              {filteredStocks.map((stock) => <button key={stock.symbol} type="button" onClick={() => { onSelectStock(stock); close(); }} className="flex w-full items-center justify-between gap-3 rounded-2xl p-3 text-left hover:bg-indigo-50 focus:bg-indigo-50 focus:outline-none dark:hover:bg-indigo-950/40 dark:focus:bg-indigo-950/40"><span><span className="text-sm font-black">{stock.symbol}</span><span className="ml-2 text-xs text-slate-500 dark:text-slate-400">{stock.name}</span></span><span className="text-sm font-black">₹{stock.price.toLocaleString('en-IN')}</span></button>)}
              {query && filteredDestinations.length === 0 && filteredStocks.length === 0 && <div className="py-10 text-center"><Command className="mx-auto h-7 w-7 text-slate-300" /><p className="mt-2 text-sm font-black">No matching page or company</p><p className="text-xs text-slate-500">Try a symbol, company name or feature.</p></div>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
