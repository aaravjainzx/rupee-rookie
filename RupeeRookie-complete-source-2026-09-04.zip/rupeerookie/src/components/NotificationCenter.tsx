import React, { useState, useRef, useEffect } from 'react';
import { Bell, X, CheckCircle, Info, AlertTriangle, AlertCircle } from 'lucide-react';
import { useSimulator } from '../context/SimulatorContext';

export const NotificationCenter: React.FC = () => {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useSimulator();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getIcon = (type: string) => {
    switch(type) {
      case 'SUCCESS': return <CheckCircle className="w-4 h-4 text-emerald-600 " />;
      case 'WARNING': return <AlertTriangle className="w-4 h-4 text-indigo-600" />;
      case 'ALERT': return <AlertCircle className="w-4 h-4 text-rose-600 " />;
      default: return <Info className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        id="notification-center-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 sm:p-2 rounded-xl bg-slate-50 hover:bg-white text-slate-900 hover:text-slate-900 border border-slate-200 hover:border-slate-900 transition-all cursor-pointer shadow-xs relative flex items-center justify-center"
        title="Alerts & Notifications"
      >
        <Bell className="w-4 h-4 text-slate-900" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-600 text-[9px] font-black text-white shadow-xs ring-2 ring-[#FFFFFF]">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden flex flex-col max-h-[80vh]">
          <div className="flex items-center justify-between p-4 border-b border-indigo-50 bg-slate-50/30">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <Bell className="w-4 h-4 text-slate-900 " /> Notifications
            </h3>
            {unreadCount > 0 && (
              <button 
                onClick={markAllNotificationsRead}
                className="text-[10px] font-bold text-slate-900 hover:text-slate-900 bg-[#E2E8F0]/50 hover:bg-slate-200 px-2 py-1 rounded-md transition-colors"
              >
                Mark all as read
              </button>
            )}
          </div>

          <div className="overflow-y-auto flex-1 p-2 space-y-1">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-500 font-medium">
                No new notifications. Set up price alerts in the market screener!
              </div>
            ) : (
              notifications.map((notif) => (
                <div 
                  key={notif.id}
                  onClick={() => markNotificationRead(notif.id)}
                  className={`p-3 rounded-xl flex items-start gap-3 cursor-pointer transition-colors ${
                    notif.read ? 'bg-transparent hover:bg-white' : 'bg-slate-50/50 hover:bg-slate-50'
                  }`}
                >
                  <div className="shrink-0 mt-0.5">
                    {getIcon(notif.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-0.5">
                      <h4 className={`text-xs font-bold truncate ${notif.read ? 'text-slate-500' : 'text-slate-900'}`}>
                        {notif.title}
                      </h4>
                      <span className="text-[9px] text-slate-500 shrink-0 font-medium whitespace-nowrap">
                        {new Date(notif.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                    </div>
                    <p className={`text-[11px] leading-snug ${notif.read ? 'text-slate-500' : 'text-zinc-700 font-medium'}`}>
                      {notif.message}
                    </p>
                  </div>
                  {!notif.read && (
                    <div className="shrink-0 w-2 h-2 rounded-full bg-slate-900 mt-1" />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
