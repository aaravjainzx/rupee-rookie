import React, { lazy, Suspense, useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { SimulatorProvider, useSimulator } from './context/SimulatorContext';
import { ThemeProvider } from './context/ThemeContext';
import type { AppTabType } from './components/Header';
import { PageSkeleton } from './components/PageSkeleton';
import { ToastNotifier } from './components/ToastNotifier';
import { ErrorBoundary } from './components/ErrorBoundary';
import { MobileBottomNav } from './components/MobileBottomNav';
import { ContextualGlossary } from './components/ContextualGlossary';
import { AccessibilityCenter } from './components/AccessibilityCenter';
import { AccessibilityProvider } from './context/AccessibilityContext';
import { DailyTipOverlay, getDailyTipStorageKey } from './components/DailyTipOverlay';
import { CommandPalette } from './components/CommandPalette';
import { ConnectionStatus } from './components/ConnectionStatus';
import type { StockDetail } from './types';

const Header = lazy(() => import('./components/Header').then((module) => ({ default: module.Header })));
const AuthPage = lazy(() => import('./components/AuthPage').then((module) => ({ default: module.AuthPage })));
const PortfolioHub = lazy(() => import('./components/PortfolioHub').then((module) => ({ default: module.PortfolioHub })));
const MarketScreener = lazy(() => import('./components/MarketScreener').then((module) => ({ default: module.MarketScreener })));
const InvestorAcademy = lazy(() => import('./components/InvestorAcademy').then((module) => ({ default: module.InvestorAcademy })));
const ChanakyaMentor = lazy(() => import('./components/ChanakyaMentor').then((module) => ({ default: module.ChanakyaMentor })));
const StockDetailModal = lazy(() => import('./components/StockDetailModal').then((module) => ({ default: module.StockDetailModal })));
const ReplayTerminal = lazy(() => import('./components/ReplayTerminal').then((module) => ({ default: module.ReplayTerminal })));
const TradeReviewHub = lazy(() => import('./components/TradeReviewHub').then((module) => ({ default: module.TradeReviewHub })));
const ProgressHub = lazy(() => import('./components/ProgressHub').then((module) => ({ default: module.ProgressHub })));
const CompoundCalculator = lazy(() => import('./components/CompoundCalculator').then((module) => ({ default: module.CompoundCalculator })));
const AppWalkthroughOverlay = lazy(() => import('./components/AppWalkthroughOverlay').then((module) => ({ default: module.AppWalkthroughOverlay })));
const HomeDashboard = lazy(() => import('./components/HomeDashboard').then((module) => ({ default: module.HomeDashboard })));
const DataPrivacyCenter = lazy(() => import('./components/DataPrivacyCenter').then((module) => ({ default: module.DataPrivacyCenter })));
const HelpSupportCenter = lazy(() => import('./components/HelpSupportCenter').then((module) => ({ default: module.HelpSupportCenter })));

function PageLoadingState() {
  return (
    <div role="status" aria-live="polite" className="min-h-[360px] rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center">
      <div className="text-center">
        <div className="mx-auto h-9 w-9 rounded-full border-2 border-indigo-200 border-t-indigo-600 animate-spin" />
        <p className="mt-3 text-xs font-bold text-slate-500 dark:text-slate-400">Preparing your workspace…</p>
      </div>
    </div>
  );
}

function SimulatorApp() {
  const { currentUser, stocks } = useSimulator();
  const [activeTab, setActiveTab] = useState<AppTabType>(() => {
    const requestedView = new URLSearchParams(window.location.search).get('view') as AppTabType | null;
    const supportedViews: AppTabType[] = ['home', 'screener', 'watchlist', 'portfolio', 'replay', 'review', 'journal', 'academy', 'challenges', 'calculator', 'chanakya', 'badges', 'privacy', 'help'];
    return requestedView && supportedViews.includes(requestedView) ? requestedView : 'home';
  });
  const [selectedStock, setSelectedStock] = useState<StockDetail | null>(null);
  const [isWalkthroughOpen, setIsWalkthroughOpen] = useState<boolean>(false);
  const [isDailyTipOpen, setIsDailyTipOpen] = useState(false);
  const [authEntryKind] = useState<'new' | 'returning' | null>(() => {
    try {
      const entry = JSON.parse(localStorage.getItem('rr_auth_entry') || 'null') as { kind?: 'new' | 'returning'; userId?: string; at?: number } | null;
      if (entry?.userId === currentUser?.id && entry.at && Date.now() - entry.at < 5 * 60_000) return entry.kind || null;
    } catch { /* Invalid legacy entry is cleared after mount. */ }
    return null;
  });

  useEffect(() => {
    localStorage.removeItem('rr_auth_entry');
  }, []);

  useEffect(() => {
    const url = new URL(window.location.href);
    url.searchParams.set('view', activeTab);
    window.history.replaceState({}, '', url);
  }, [activeTab]);

  // Keep each workspace exactly where the learner left it when moving between sections.
  useEffect(() => {
    const savedPosition = Number(sessionStorage.getItem(`rr_scroll_${activeTab}`) || 0);
    const frame = window.requestAnimationFrame(() => window.scrollTo({ top: savedPosition, behavior: 'auto' }));
    return () => {
      window.cancelAnimationFrame(frame);
      sessionStorage.setItem(`rr_scroll_${activeTab}`, String(window.scrollY));
    };
  }, [activeTab]);

  // New accounts receive the tour; returning users receive one deterministic tip per IST day.
  useEffect(() => {
    if (currentUser) {
      const storageKey = `rupeerookie_walkthrough_completed_${currentUser.id}`;
      const legacyStorageKey = `tradelab_walkthrough_completed_${currentUser.id}`;
      const hasSeenTour = localStorage.getItem(storageKey) || localStorage.getItem(legacyStorageKey);

      if (authEntryKind === 'new' || (!authEntryKind && !hasSeenTour)) {
        const timer = setTimeout(() => {
          setIsWalkthroughOpen(true);
        }, 600);
        return () => clearTimeout(timer);
      }

      const dailyTipKey = getDailyTipStorageKey(currentUser.id);
      if (!localStorage.getItem(dailyTipKey)) {
        const timer = window.setTimeout(() => {
          localStorage.setItem(dailyTipKey, 'true');
          setIsDailyTipOpen(true);
        }, 900);
        return () => window.clearTimeout(timer);
      }
    }
  }, [authEntryKind, currentUser]);

  const handleOpenChanakyaWithStock = (stock: StockDetail) => {
    setSelectedStock(null);
    setActiveTab('chanakya');
  };

  // If not logged in, gate the entire app and show the dedicated full-screen Login / Signup page
  if (!currentUser) {
    return (
      <>
        <Suspense fallback={<PageLoadingState />}><AuthPage /></Suspense>
        <ToastNotifier />
      </>
    );
  }

  return (
    <div className="min-h-screen max-w-full overflow-x-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white antialiased transition-colors duration-200">
      <a href="#main-content" className="skip-link">Skip to main content</a>
      {/* Top Fixed Header with live tickers & Net Worth */}
      <Suspense fallback={<div role="status" className="h-40 border-b border-slate-200 dark:border-slate-800"><span className="sr-only">Loading navigation…</span></div>}><Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onStartWalkthrough={() => setIsWalkthroughOpen(true)}
      /></Suspense>

      {/* Main Content Area */}
      <main id="main-content" tabIndex={-1} className="flex-1 max-w-7xl w-full mx-auto p-4 pb-28 sm:p-6 sm:pb-28 lg:p-8 outline-none">
        <Suspense fallback={activeTab === 'screener' ? <PageSkeleton page="markets" /> : activeTab === 'portfolio' || activeTab === 'watchlist' ? <PageSkeleton page="portfolio" /> : activeTab === 'academy' ? <PageSkeleton page="academy" /> : <PageLoadingState />}>
          <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div key="home" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <HomeDashboard setActiveTab={setActiveTab} />
            </motion.div>
          )}
          {activeTab === 'screener' && (
            <motion.div key="screener" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <MarketScreener 
                onSelectStock={(stock) => setSelectedStock(stock)} 
              />
            </motion.div>
          )}

          {(activeTab === 'portfolio' || activeTab === 'watchlist') && (
            <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <PortfolioHub
                onSelectStock={(stock) => setSelectedStock(stock)}
                onNavigateToScreener={() => setActiveTab('screener')}
                initialSection={activeTab === 'watchlist' ? 'watchlist' : 'positions'}
              />
            </motion.div>
          )}

          {activeTab === 'replay' && (
            <motion.div key="replay" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <ReplayTerminal />
            </motion.div>
          )}

          {(activeTab === 'review' || activeTab === 'journal') && (
            <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <TradeReviewHub initialTab={activeTab === 'journal' ? 'JOURNAL' : 'DNA'} />
            </motion.div>
          )}

          {activeTab === 'academy' && (
            <motion.div key="academy" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <InvestorAcademy />
            </motion.div>
          )}

          {(activeTab === 'challenges' || activeTab === 'badges') && (
            <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <ProgressHub initialSection={activeTab === 'badges' ? 'achievements' : 'challenges'} />
            </motion.div>
          )}

          {activeTab === 'calculator' && (
            <motion.div key="calculator" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <CompoundCalculator />
            </motion.div>
          )}

          {activeTab === 'chanakya' && (
            <motion.div key="chanakya" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <ChanakyaMentor />
            </motion.div>
          )}

          {activeTab === 'privacy' && (
            <motion.div key="privacy" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}><DataPrivacyCenter /></motion.div>
          )}
          {activeTab === 'help' && (
            <motion.div key="help" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}><HelpSupportCenter setActiveTab={setActiveTab} /></motion.div>
          )}
          </AnimatePresence>
        </Suspense>
      </main>

      {/* Stock Deep Analysis & Trading Modal */}
      {selectedStock && (
        <Suspense fallback={null}>
          <StockDetailModal
            stock={selectedStock}
            onClose={() => setSelectedStock(null)}
            onOpenChanakyaWithContext={handleOpenChanakyaWithStock}
          />
        </Suspense>
      )}

      {/* App Walkthrough Tutorial Overlay */}
      <Suspense fallback={null}>
        <AppWalkthroughOverlay
          isOpen={isWalkthroughOpen}
          onClose={() => setIsWalkthroughOpen(false)}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      </Suspense>

      {/* Global Notification Toast Container */}
      <ToastNotifier />
      <ConnectionStatus />
      <ContextualGlossary activeTab={activeTab} />
      <AccessibilityCenter />
      <MobileBottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
      <CommandPalette
        stocks={stocks}
        onNavigate={setActiveTab}
        onSelectStock={(stock) => setSelectedStock(stock)}
      />

      <AnimatePresence>
        {isDailyTipOpen && currentUser && (
          <DailyTipOverlay
            user={currentUser}
            onClose={() => setIsDailyTipOpen(false)}
            onNavigate={(tab) => {
              setIsDailyTipOpen(false);
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-6 pb-24 lg:pb-6 text-xs text-slate-500 dark:text-slate-400 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-indigo-600 to-violet-600 text-white font-black flex items-center justify-center text-xs shadow-xs">
              ₹
            </div>
            <span className="font-bold text-slate-900 dark:text-slate-100">RupeeRookie</span>
            <span>— Indian paper trading simulator & investor academy</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500 dark:text-slate-400 font-medium flex-wrap justify-center">
            <span className="text-amber-700 dark:text-amber-300 font-semibold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
              Indicative, delayed or last-close NSE/BSE data
            </span>
            <span>•</span>
            <span className="text-slate-700 dark:text-slate-300 font-semibold">75+ Curated Indian Companies</span>
            <span>•</span>
            <span className="text-slate-700 dark:text-slate-300 font-semibold">₹10,00,000 Virtual Capital</span>
            <span>•</span>
            <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Educational simulation — not investment advice</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AccessibilityProvider>
          <SimulatorProvider>
            <SimulatorApp />
          </SimulatorProvider>
        </AccessibilityProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
