# RupeeRookie

RupeeRookie is an educational Indian-market paper trading simulator and investor academy. It includes virtual capital, indicative NSE/BSE quotes, portfolio and order tracking, market replay, learning modules, risk guardrails, challenges, and optional Gemini-powered explanations.

## Run locally

Requirements: Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open `http://localhost:3000` and use the one-click demo account, or create a local account. Demo credentials are shown in the app.

The simulator works without an AI key. To enable Chanakya AI features, copy `.env.example` to `.env` and add a valid `GEMINI_API_KEY`.

## Checks

```bash
npm run lint
npm run build
```

## Important

RupeeRookie is for education and practice only. Quotes may be delayed or unavailable, simulated performance does not represent real trading, and nothing in the app is investment advice.
